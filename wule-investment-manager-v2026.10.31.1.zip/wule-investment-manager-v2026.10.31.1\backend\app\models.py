from datetime import date, datetime
from decimal import Decimal
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Number = Decimal


class Trade(BaseModel):
    price: Number = Field(gt=0, max_digits=18, decimal_places=6)
    quantity: Number = Field(gt=0, max_digits=18, decimal_places=6)
    fee: Number = Field(default=Decimal('0'), ge=0, max_digits=18, decimal_places=6)
    note: str = Field(default='', max_length=1000)


class ProjectCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    category: str = Field(default='stock', pattern=r'^[a-z][a-z0-9_]{0,19}$')
    code: str | None = Field(default=None, pattern=r'^[A-Za-z0-9.]{1,20}$')
    instrument_name: str | None = Field(default=None, min_length=1, max_length=100)
    price: Number | None = Field(default=None, gt=0, max_digits=18, decimal_places=6)
    quantity: Number | None = Field(default=None, gt=0, max_digits=18, decimal_places=6)
    fee: Number = Field(default=Decimal('0'), ge=0, max_digits=18, decimal_places=6)
    note: str = Field(default='', max_length=1000)
    current_price: Number | None = Field(default=None, gt=0, max_digits=18, decimal_places=6)
    started_on: date | None = None
    settle_pnl: Number | None = Field(default=None, max_digits=18, decimal_places=2)
    count_assets: bool = False  # 仅平账项目：勾选后盈亏计入总资产，否则冲减/回补累计本金
    skip_daily: bool = True  # 仅平账项目：默认不计入当日盈亏，避免历史平账金额冲垮今日盈亏

    @model_validator(mode='after')
    def required_fields(self):
        if self.category == 'settle':
            # 平账项目不绑定标的，只记录历史盈亏金额。
            if self.settle_pnl is None:
                raise ValueError('平账项目必须填写盈亏金额')
        else:
            if not self.code or not self.instrument_name:
                raise ValueError('请填写标的代码和标的名称')
            if self.price is None or self.quantity is None:
                raise ValueError('请填写买入价格和数量')
        return self


class OperationCreate(Trade):
    kind: Literal['buy', 'sell', 'close']
    expected_version: int = Field(ge=1)
    ended_on: date | None = None
    executed_at: datetime | None = None

    @field_validator('executed_at')
    @classmethod
    def not_future(cls, v: datetime | None):
        # 补录历史操作可指定成交时间，但不允许伪造未来时间。
        if v and v > datetime.now(v.tzinfo).replace(tzinfo=v.tzinfo):
            raise ValueError('操作时间不能晚于当前时间')
        return v


class DipPlanCreate(BaseModel):
    """定投计划：每期按设定价格买入固定金额，到期自动执行。"""
    amount: Number = Field(gt=0, max_digits=18, decimal_places=2)
    price: Number = Field(gt=0, max_digits=18, decimal_places=6)
    period: Literal['weekly', 'biweekly', 'monthly']
    start_date: date


class ProjectDates(BaseModel):
    started_on: date | None = None
    ended_on: date | None = None
    expected_version: int = Field(ge=1)

    @model_validator(mode='after')
    def dates(self):
        if self.started_on and self.ended_on and self.ended_on < self.started_on:
            raise ValueError('结束日期不能早于开始日期')
        return self


class Adjustment(BaseModel):
    amount: Number = Field(max_digits=18, decimal_places=2)
    reason: str = Field(min_length=1, max_length=500)


class ProjectAlerts(BaseModel):
    """结项提醒阈值：正数金额；传 None/空串表示清除该提醒。"""
    alert_profit: Number | None = None
    alert_loss: Number | None = None

    @model_validator(mode='after')
    def positive(self):
        for v in (self.alert_profit, self.alert_loss):
            if v is not None and v < 0:
                raise ValueError('提示线金额不能为负数')
        return self


class DailyInclude(BaseModel):
    """平账项目当日盈亏口径开关：include=True 计入当日盈亏，False 排除（默认）。

    strict 模式拒绝 pydantic 默认的宽松布尔转换（如字符串 "yes"/"1"），
    非布尔输入直接 422，与需求边界一致。
    """
    model_config = ConfigDict(strict=True)
    include: bool


class OperationUpdate(BaseModel):
    """修改一笔操作的价格/数量/手续费/备注（提供哪个改哪个），后端全量重放项目账务。

    与 OperationCreate 不同：字段全部可选（仅传 fee 即可只改手续费），expected_version 乐观锁必填。
    """
    price: Number | None = Field(default=None, gt=0, max_digits=18, decimal_places=6)
    quantity: Number | None = Field(default=None, gt=0, max_digits=18, decimal_places=6)
    fee: Number | None = Field(default=None, ge=0, max_digits=18, decimal_places=6)
    note: str | None = Field(default=None, max_length=1000)
    expected_version: int = Field(ge=1)


class GoalCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    period: Literal['year', 'quarter', 'month']
    project_id: str | None = None
    target: Number = Field(gt=0, max_digits=18, decimal_places=2)
    starts_on: date
    ends_on: date

    @model_validator(mode='after')
    def dates(self):
        if self.ends_on < self.starts_on:
            raise ValueError('结束日期不能早于开始日期')
        return self


class GoalUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=100)
    period: Literal['year', 'quarter', 'month'] | None = None
    project_id: str | None = None
    target: Number | None = Field(default=None, gt=0, max_digits=18, decimal_places=2)
    starts_on: date | None = None
    ends_on: date | None = None

    @model_validator(mode='after')
    def dates(self):
        if self.starts_on and self.ends_on and self.ends_on < self.starts_on:
            raise ValueError('结束日期不能早于开始日期')
        return self


class StrategyCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    tags: list[str] = Field(default_factory=list, max_length=20)
    trigger_conditions: str = ''
    buy_logic: str = ''
    sell_logic: str = ''
    position_rules: str = ''
    stop_loss: str = ''
    review: str = ''
    project_ids: list[str] = Field(default_factory=list, max_length=100)


class ImportConfirm(BaseModel):
    projects: list[ProjectCreate] = Field(min_length=1, max_length=100)


class ReportCreate(BaseModel):
    format: Literal['xlsx', 'pdf', 'png']
    category: str | None = None
    status: Literal['active', 'closed'] | None = None
    starts_on: date | None = None
    ends_on: date | None = None

    @model_validator(mode='after')
    def dates(self):
        if self.starts_on and self.ends_on and self.ends_on < self.starts_on:
            raise ValueError('结束日期不能早于开始日期')
        return self
