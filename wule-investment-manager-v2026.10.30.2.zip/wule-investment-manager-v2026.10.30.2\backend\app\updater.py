﻿"""版本检查与一键升级：从公共发布仓库读取 version.json，下载发布包覆盖程序文件。

只覆盖程序文件（backend/、frontend/、requirements.txt、scripts/、根目录 .bat/.md），
绝不触碰 data/ 用户数据。升级需重启应用生效；仅发布包布局（根目录有启动.bat）
支持应用内自动重启。
"""
import os
import re
import shutil
import tempfile
import zipfile
from pathlib import Path

import httpx

VERSION = 'v2026.10.30.2'
RELEASE_REPO = 'WGJDZT/wule-releases'
RAW = f'https://raw.githubusercontent.com/{RELEASE_REPO}/main'
ROOT = Path(__file__).resolve().parents[2]
MAX_PKG = 200 * 1024 * 1024  # 更新包上限 200MB
ALLOW_PREFIX = ('backend/', 'frontend/', 'scripts/', 'requirements.txt')
ALLOW_ROOT_FILE = re.compile(r'^[^/\\]+\.(bat|md)$')


def _parse(v: str):
    """解析 vYYYY.M.D[.N] 版本号，支持同日多次发布的多段版本；末段缺省补 0。"""
    m = re.match(r'^v?(\d+(?:\.\d+)*)$', (v or '').strip())
    if not m:
        return None
    parts = [int(x) for x in m.group(1).split('.')]
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def newer(latest: str, current: str) -> bool:
    a, b = _parse(latest), _parse(current)
    if a and b:
        return a > b
    return bool(latest) and latest != current


def check() -> dict:
    """读取发布仓库 version.json 与本地版本比对；失败返回 error 字段不抛异常。"""
    try:
        r = httpx.get(f'{RAW}/version.json', timeout=10)
        if r.status_code != 200:
            return {'current': VERSION, 'latest': None, 'has_update': False,
                    'error': f'发布仓库读取失败（HTTP {r.status_code}）'}
        info = r.json()
    except Exception as e:
        return {'current': VERSION, 'latest': None, 'has_update': False, 'error': str(e)[:200]}
    latest = info.get('version') or ''
    return {'current': VERSION, 'latest': latest, 'has_update': newer(latest, VERSION),
            'notes': info.get('notes') or '', 'file': info.get('file') or '',
            'published_at': info.get('published_at') or ''}


def _allowed(name: str) -> bool:
    n = name.replace('\\', '/')
    if n.endswith('/'):
        return True
    if n.startswith(('data/', '.venv/', 'node_modules/')) or '..' in Path(n).parts:
        return False
    return n.startswith(ALLOW_PREFIX) or bool(ALLOW_ROOT_FILE.match(n))


def _strip_prefix(names):
    """发布 zip 若带唯一顶层目录（如 wule-investment-manager-vX/），剥离后再校验解压。"""
    first = [n.replace('\\', '/') for n in names]
    roots = {n.split('/')[0] for n in first if n}
    if len(roots) == 1 and '/' in first[0]:
        prefix = roots.pop() + '/'
        return prefix, [n[len(prefix):] for n in first]
    return '', first


def apply_update() -> dict:
    """下载最新发布包并覆盖程序文件，返回更新结果（需重启生效）。"""
    info = check()
    if info.get('error'):
        raise RuntimeError(info['error'])
    if not info.get('has_update'):
        raise RuntimeError('当前已是最新版本')
    if not info.get('file'):
        raise RuntimeError('发布信息缺少更新包文件名')
    url = f"{RAW}/{info['file']}"
    tmp = tempfile.NamedTemporaryFile(suffix='.zip', delete=False)
    tmp.close()
    zpath = Path(tmp.name)
    try:
        with httpx.stream('GET', url, timeout=180, follow_redirects=True) as r:
            if r.status_code != 200:
                raise RuntimeError(f'更新包下载失败（HTTP {r.status_code}）')
            total = 0
            with open(zpath, 'wb') as f:
                for chunk in r.iter_bytes(256 * 1024):
                    total += len(chunk)
                    if total > MAX_PKG:
                        raise RuntimeError('更新包超过 200MB，已中止')
                    f.write(chunk)
        with zipfile.ZipFile(zpath) as z:
            prefix, names = _strip_prefix(z.namelist())
            bad = [n for n in names if not _allowed(n)]
            if bad:
                raise RuntimeError(f'更新包含非法路径 {bad[0]}，已拒绝')
            count = 0
            for old, new in zip(z.namelist(), names):
                if new.endswith('/'):
                    continue
                target = ROOT / new
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(old) as fin, open(target, 'wb') as fout:
                    shutil.copyfileobj(fin, fout)
                count += 1
        return {'updated_to': info['latest'], 'files': count, 'restart': True}
    finally:
        zpath.unlink(missing_ok=True)


def restart_command():
    """生成重启辅助脚本命令；仅发布包布局（根目录有启动.bat）支持，否则返回 None。"""
    if not any(ROOT.glob('*.bat')):
        return None
    # 辅助脚本必须纯 ASCII（bat 不支持 BOM/中文路径）：
    # 杀当前进程 → 等待 → 用通配符拉起根目录唯一的启动 bat（避开中文文件名）。
    helper = Path(tempfile.gettempdir()) / 'wule-restart.bat'
    helper.write_text(
        '@echo off\r\n'
        f'taskkill /PID {os.getpid()} /F >nul 2>&1\r\n'
        'timeout /t 2 /nobreak >nul\r\n'
        f'cd /d "{ROOT}"\r\n'
        'for %%f in (*.bat) do start "" "%%f"\r\n',
        encoding='ascii')
    return ['cmd', '/c', 'start', '/min', str(helper)]
