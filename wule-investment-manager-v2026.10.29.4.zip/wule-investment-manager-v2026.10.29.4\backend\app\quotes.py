"""Best-effort public quotation adapter. Failed quotes never replace stored prices."""
import re
import html
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from decimal import Decimal
import httpx
from .accounting import now, TZ, snapshot
from .db import connect


def symbol(code, category='stock'):
    code = code.lower()
    if re.fullmatch(r'(sh|sz|bj)\d{6}', code):
        return code
    if not re.fullmatch(r'\d{6}', code):
        raise ValueError('当前适配器仅支持沪深北六位证券代码')
    if category == 'fund' and not code.startswith(('15', '16', '50', '51', '56', '58')):
        raise ValueError('场外基金应使用独立净值源，不能使用同码股票行情')
    return ('sh' if code[0] in '569' else 'bj' if code[0] in '48' else 'sz') + code


def quote_at(code, category='stock'):
    """返回该标的行情缓存中的市场数据时间；无缓存或不适用时为 None。"""
    is_nav = category == 'fund' and re.fullmatch(r'\d{6}', str(code)) and not str(code).startswith(('15', '16', '50', '51', '56', '58'))
    if is_nav:
        ticker = 'fund:' + str(code)
    else:
        try:
            ticker = symbol(str(code), category)
        except ValueError:
            return None
    with connect() as db:
        row = db.execute('SELECT market_at FROM quote_cache WHERE symbol=?', (ticker,)).fetchone()
    return row['market_at'] if row else None


def fetch_quote(code, category='stock', force=False):
    is_nav=category=='fund' and re.fullmatch(r'\d{6}',code) and not code.startswith(('15','16','50','51','56','58'))
    ticker = 'fund:'+code if is_nav else symbol(code, category)
    with connect() as db:
        cached = db.execute('SELECT * FROM quote_cache WHERE symbol=?', (ticker,)).fetchone()
    if cached and not force and datetime.fromisoformat(cached['fetched_at']) > datetime.now(TZ)-timedelta(seconds=60):
        return dict(cached)
    if is_nav:
        response=httpx.get('https://api.fund.eastmoney.com/f10/lsjz',params={'fundCode':code,'pageIndex':1,'pageSize':2},
                           headers={'Referer':'https://fund.eastmoney.com/'},timeout=8)
        response.raise_for_status()
        rows=response.json().get('Data',{}).get('LSJZList',[])
        if not rows or not rows[0].get('DWJZ') or Decimal(rows[0]['DWJZ'])<=0:
            raise ValueError('基金源未返回有效单位净值')
        name=cached['name'] if cached else ''
        if not name:
            try:
                meta=httpx.get(f'https://fundf10.eastmoney.com/jbgk_{code}.html',timeout=8)
                meta.raise_for_status()
                title=re.search(r'<title>(.*?)</title>',meta.text,re.S)
                if title:name=html.unescape(re.split(r'[（(]',title[1])[0]).strip()
            except httpx.HTTPError:pass
        market_at=datetime.strptime(rows[0]['FSRQ'],'%Y-%m-%d').replace(hour=15,tzinfo=TZ).isoformat()
        item=dict(symbol=ticker,name=name,price=str(Decimal(rows[0]['DWJZ'])),
                  previous_close=str(Decimal(rows[1]['DWJZ'])) if len(rows)>1 and rows[1].get('DWJZ') else None,
                  provider='东方财富已发布单位净值',market_at=market_at,fetched_at=now())
    else:
        response = httpx.get('https://qt.gtimg.cn/q='+ticker, timeout=8, headers={'Referer':'https://gu.qq.com/'})
        response.raise_for_status()
        response.encoding = 'gb18030'
        parts = response.text.split('"')
        fields = parts[1].split('~') if len(parts)>1 else []
        if len(fields)<31 or not fields[3] or Decimal(fields[3]) <= 0:
            raise ValueError('数据源未返回有效行情')
        market_at = datetime.strptime(fields[30], '%Y%m%d%H%M%S').replace(tzinfo=TZ).isoformat()
        item = dict(symbol=ticker,name=fields[1],price=str(Decimal(fields[3])),previous_close=str(Decimal(fields[4])),
                    provider='腾讯财经（非交易级）',market_at=market_at,fetched_at=now())
    with connect(True) as db:
        db.execute('''INSERT INTO quote_cache VALUES(:symbol,:name,:price,:previous_close,:provider,:market_at,:fetched_at)
            ON CONFLICT(symbol) DO UPDATE SET name=excluded.name,price=excluded.price,previous_close=excluded.previous_close,
            provider=excluded.provider,market_at=excluded.market_at,fetched_at=excluded.fetched_at''',item)
    return item


def refresh_quotes():
    """刷新所有 active 项目的行情：并发最多 5 只，腾讯/东财内部自带 60s 缓存。"""
    with connect() as db:
        holdings = db.execute(
            "SELECT DISTINCT code,category FROM projects "
            "WHERE status='active' AND category IN ('stock','fund') AND current_price IS NOT NULL"
        ).fetchall()
    errors, updated = [], 0

    def _one(row):
        try:
            quote = fetch_quote(row['code'], row['category'])
            with connect(True) as db:
                cur = db.execute(
                    '''UPDATE projects SET current_price=?,previous_close=?,quote_at=?,version=version+1
                       WHERE code=? AND category=? AND status='active' AND (quote_at IS NULL OR quote_at<?)''',
                    (quote['price'], quote['previous_close'], quote['market_at'],
                     row['code'], row['category'], quote['market_at']))
            return row['code'], cur.rowcount
        except Exception as exc:
            errors.append({'code': row['code'], 'error': str(exc)[:200]})
            return row['code'], 0

    with ThreadPoolExecutor(max_workers=min(5, len(holdings) or 1)) as ex:
        futures = {ex.submit(_one, row): row for row in holdings}
        for fut in as_completed(futures):
            updated += 1 if fut.result()[1] > 0 else 0

    with connect(True) as db:
        snapshot(db)
    return {'updated': updated, 'errors': errors, 'total': len(holdings), 'completed_at': now()}
