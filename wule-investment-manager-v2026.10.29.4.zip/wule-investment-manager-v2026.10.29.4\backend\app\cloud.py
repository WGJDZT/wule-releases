"""GitHub 云同步：数据包推送到私有仓库 / 从私有仓库拉取并恢复。

设计约束：
- 令牌仅存本机 SQLite settings 表（GET 掩码显示，POST 留空保持不变），不写日志。
- 传输走 git 协议（令牌嵌入临时 URL），所有错误输出先脱敏再抛出。
- 仓库默认 WGJDZT/wule-data，不存在时通过 API 自动创建为**私有**仓库。
"""
import os
import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path

import httpx

from . import backup
from .accounting import TZ
from .db import connect

SETTING_KEYS = ('github_token', 'github_repo')
DEFAULT_REPO = 'WGJDZT/wule-data'
ZIP_NAME = 'wule-data.zip'
API = 'https://api.github.com'


def get_settings():
    with connect() as db:
        rows = db.execute(
            f"SELECT key,value FROM settings WHERE key IN ({','.join('?' * len(SETTING_KEYS))})",
            SETTING_KEYS).fetchall()
    cfg = {r['key']: r['value'] for r in rows}
    token = cfg.get('github_token') or ''
    return {
        'repo': cfg.get('github_repo') or DEFAULT_REPO,
        'has_token': bool(token),
        'token_masked': ('*' * 8 + token[-4:]) if token else '',
    }


def save_settings(repo: str, token):
    """token 传 None 表示保持不变，传空串表示清除。"""
    with connect() as db:
        if repo.strip():
            db.execute('INSERT INTO settings(key,value) VALUES(?,?) '
                       'ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                       ('github_repo', repo.strip()))
        if token is not None:
            db.execute('INSERT INTO settings(key,value) VALUES(?,?) '
                       'ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                       ('github_token', token.strip()))


def _config():
    with connect() as db:
        rows = db.execute(
            f"SELECT key,value FROM settings WHERE key IN ({','.join('?' * len(SETTING_KEYS))})",
            SETTING_KEYS).fetchall()
    cfg = {r['key']: r['value'] for r in rows}
    token = cfg.get('github_token') or ''
    if not token:
        raise PermissionError('请先在设置中配置 GitHub 令牌')
    return token, (cfg.get('github_repo') or DEFAULT_REPO)


def _scrub(text: str, token: str) -> str:
    return (text or '').replace(token, '***').strip()[-400:]


def _headers(token: str):
    return {'Authorization': f'Bearer {token}', 'Accept': 'application/vnd.github+json'}


def _url(repo: str, token: str) -> str:
    return f'https://x-access-token:{token}@github.com/{repo}.git'


def _git(args, cwd, token: str) -> str:
    env = dict(os.environ, GIT_TERMINAL_PROMPT='0')
    p = subprocess.run(['git', *args], cwd=str(cwd), capture_output=True,
                       timeout=300, env=env, encoding='utf-8', errors='replace')
    out = (p.stdout or '') + (p.stderr or '')
    if p.returncode != 0:
        raise RuntimeError(_scrub(out, token))
    return out


def _ensure_repo(token: str, repo: str) -> str:
    """仓库不存在时自动创建为私有仓库，返回实际 full_name。

    区分两种 owner：
    - /user/repos/{login} → POST /user/repos  创建个人仓库
    - /orgs/{org}         → POST /orgs/{org}/repos 创建 org 仓库
    如果令牌没有在该 org 下创建仓库的权限（没加 create_repo scope 或 org 禁止第三方创建），
    返回明确的 403 提示，让用户先手动在网页建仓库再回来用。
    """
    owner, _, name = repo.partition('/')
    name = name or owner
    r = httpx.get(f'{API}/repos/{repo}', headers=_headers(token), timeout=15)
    if r.status_code == 200:
        return repo
    if r.status_code != 404:
        raise RuntimeError(f'仓库检查失败（HTTP {r.status_code}）：{_scrub(r.text, token)}')

    # 仓库不存在 → 判断 owner 类型
    whoami = httpx.get(f'{API}/user', headers=_headers(token), timeout=15)
    if whoami.status_code != 200:
        raise RuntimeError(f'令牌无效，无法识别当前 GitHub 用户（HTTP {whoami.status_code}）。请检查令牌是否有 user/read 权限：{_scrub(whoami.text, token)}')
    login = whoami.json().get('login')

    if login and login.lower() == owner.lower():
        # 个人仓库：POST /user/repos
        endpoint = f'{API}/user/repos'
    else:
        # org 或他人：POST /orgs/{owner}/repos
        endpoint = f'{API}/orgs/{owner}/repos'

    payload = {'name': name, 'private': True, 'auto_init': True,
               'description': 'wule investment manager data backup'}
    r2 = httpx.post(endpoint, headers=_headers(token), timeout=15, json=payload)
    if r2.status_code in (200, 201):
        return r2.json()['full_name']
    if r2.status_code == 403 and endpoint.endswith('/repos'):
        # org 创建失败：很可能令牌没 org 创建仓库权限，让用户手动建
        raise RuntimeError(
            f'仓库 {repo} 不存在，且自动创建失败——令牌没有在 {owner} 下创建仓库的权限（HTTP 403）。'
            f'请先在 GitHub 网页上为 {owner} 创建一个名为 "{name}" 的**私有**仓库（不需要任何文件），'
            f'然后回到本程序点「云端备份」，之后就会自动推送。'
        )
    raise RuntimeError(f'仓库不存在且自动创建失败（HTTP {r2.status_code}）：{_scrub(r2.text, token)}')


def push() -> dict:
    """打包当前数据并推送到云端仓库（单文件 wule-data.zip 覆盖式备份）。"""
    token, repo = _config()
    repo = _ensure_repo(token, repo)
    tmp = Path(tempfile.mkdtemp(prefix='wule-cloud-'))
    try:
        zip_path = tmp / ZIP_NAME
        stats = backup.build_zip(zip_path)
        work = tmp / 'repo'
        _git(['clone', '--depth', '1', _url(repo, token), 'repo'], tmp, token)
        shutil.copy2(zip_path, work / ZIP_NAME)
        _git(['add', ZIP_NAME], work, token)
        try:
            _git(['-c', 'user.name=wule-app', '-c', 'user.email=wule-app@local',
                  'commit', '-m', f"data backup {datetime.now(TZ):%Y-%m-%d %H:%M}"], work, token)
        except RuntimeError as e:
            if 'nothing to commit' in str(e):
                return {'repo': repo, 'size': stats['size'], 'pushed': False, 'message': '数据无变化'}
            raise
        _git(['push', 'origin', 'HEAD:main'], work, token)
        return {'repo': repo, 'size': stats['size'], 'pushed': True}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def pull() -> dict:
    """从云端仓库拉取数据包并恢复（恢复前自动备份当前数据）。"""
    token, repo = _config()
    tmp = Path(tempfile.mkdtemp(prefix='wule-cloud-'))
    try:
        try:
            _git(['clone', '--depth', '1', _url(repo, token), 'repo'], tmp, token)
        except RuntimeError as e:
            raise RuntimeError(f'拉取失败，请检查令牌与仓库名：{e}')
        z = tmp / 'repo' / ZIP_NAME
        if not z.is_file():
            raise RuntimeError('云端仓库中还没有数据包，请先执行一次云端备份')
        stats = backup.restore_zip(z)
        return {'repo': repo, **stats}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
