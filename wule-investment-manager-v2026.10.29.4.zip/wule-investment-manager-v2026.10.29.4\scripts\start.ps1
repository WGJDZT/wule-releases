﻿param([switch]$Demo)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$pythonExe = Join-Path $projectRoot '.venv/Scripts/python.exe'
if (-not (Test-Path -LiteralPath $pythonExe)) { throw '请先按 README 创建 .venv 并安装后端依赖。' }
if (-not (Test-Path -LiteralPath (Join-Path $projectRoot 'frontend/dist/index.html'))) { throw '请先在 frontend 执行 npm ci 和 npm run build。' }
if ($Demo) {
    $env:WULE_DATA_DIR = Join-Path $projectRoot 'data/demo'
    Write-Host '演示模式：仅使用 data/demo 数据库，端口 8010（与正式 8000 互不干扰）。'
    Write-Host '浏览器访问 http://127.0.0.1:8010；按 Ctrl+C 停止。'
    & $pythonExe -m uvicorn app.main:app --app-dir (Join-Path $projectRoot 'backend') --host 0.0.0.0 --port 8010
    exit $LASTEXITCODE
}
Write-Host '正式模式：数据目录 data，端口 8000。开发请改用 scripts/dev.ps1（8001 + data/dev）。'
Write-Host '浏览器访问 http://127.0.0.1:8000；按 Ctrl+C 停止。'
& $pythonExe -m uvicorn app.main:app --app-dir (Join-Path $projectRoot 'backend') --host 0.0.0.0 --port 8000
exit $LASTEXITCODE
