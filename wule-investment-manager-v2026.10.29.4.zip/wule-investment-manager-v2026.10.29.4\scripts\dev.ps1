param([switch]$CopyProd)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$pythonExe = Join-Path $projectRoot '.venv/Scripts/python.exe'
if (-not (Test-Path -LiteralPath $pythonExe)) { throw '请先按 README 创建 .venv 并安装后端依赖。' }
if (-not (Test-Path -LiteralPath (Join-Path $projectRoot 'frontend/dist/index.html'))) { throw '请先在 frontend 执行 npm ci 和 npm run build。' }
$devData = Join-Path $projectRoot 'data/dev'
New-Item -ItemType Directory -Force -Path $devData | Out-Null
if ($CopyProd -and -not (Test-Path (Join-Path $devData 'wule.db'))) {
    $prodDb = Join-Path $projectRoot 'data/wule.db'
    if (Test-Path -LiteralPath $prodDb) {
        Copy-Item -LiteralPath $prodDb -Destination (Join-Path $devData 'wule.db')
        Write-Host '已复制正式数据库快照到 data/dev（仅首次）。'
    }
}
$env:WULE_DATA_DIR = $devData
Write-Host '开发模式：数据目录 data/dev，端口 8001，代码改动自动重载。'
Write-Host '浏览器访问 http://127.0.0.1:8001；按 Ctrl+C 停止。'
Write-Host '前端联调：npm run dev 前设置 VITE_API_TARGET=http://127.0.0.1:8001。'
& $pythonExe -m uvicorn app.main:app --app-dir (Join-Path $projectRoot 'backend') --host 127.0.0.1 --port 8001 --reload
exit $LASTEXITCODE
