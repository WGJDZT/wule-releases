@echo off
title Wule Investment Manager
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python not found. Install Python 3.11+ and check "Add Python to PATH".
  echo Download: https://www.python.org/downloads/
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo First run: creating environment and installing dependencies, 1-3 minutes...
  python -m venv .venv
  if errorlevel 1 ( echo [ERROR] Failed to create virtual environment. & pause & exit /b 1 )
  ".venv\Scripts\python.exe" -m pip install --upgrade pip -q
  ".venv\Scripts\python.exe" -m pip install -r backend\requirements.txt -q -i https://pypi.tuna.tsinghua.edu.cn/simple
  if errorlevel 1 ( echo [ERROR] Dependency install failed. Check network, then run this file again. & pause & exit /b 1 )
  echo Environment ready.
)

echo.
echo Starting server... Your browser will open http://127.0.0.1:8080
echo All data is saved in the local "data" folder. Close this window or press Ctrl+C to stop.
echo.
start "" http://127.0.0.1:8080
".venv\Scripts\python.exe" -m uvicorn app.main:app --app-dir backend --host 127.0.0.1 --port 8080
pause
