import json
import os
import re
import shutil
from pathlib import Path
from PIL import Image, ImageOps
from .db import connect


def engine_path():
    if os.environ.get('TESSERACT_CMD'):
        return os.environ['TESSERACT_CMD']
    local=Path(__file__).resolve().parents[2]/'.tools'/'tesseract'/'tesseract.exe'
    standard=Path(os.environ.get('ProgramFiles','C:/Program Files'))/'Tesseract-OCR'/'tesseract.exe'
    return str(local) if local.exists() else str(standard) if standard.exists() else shutil.which('tesseract') or 'tesseract'


def engine_status():
    import pytesseract
    pytesseract.pytesseract.tesseract_cmd=engine_path()
    try:
        languages=pytesseract.get_languages(config='')
        required=os.environ.get('WULE_OCR_LANG','chi_sim+eng').split('+')
        missing=[lang for lang in required if lang not in languages]
        return {'ready':not missing,'languages':languages,'missing_languages':missing,'error':None if not missing else '缺少语言包：'+','.join(missing)}
    except Exception as exc:
        return {'ready':False,'languages':[],'missing_languages':[],'error':str(exc)[:500]}


def parse_text(text):
    """Conservative candidates: never infer a column's meaning from number order."""
    rows = []
    aliases = {'price':r'成本(?:价)?','quantity':r'持仓(?:数量)?|数量|份额',
               'current_price':r'现价|当前价|最新价','pnl':r'盈亏(?:金额)?'}
    header=None
    header_aliases={'code':r'(?:证券|股票|基金)?代码','instrument_name':r'(?:证券|股票|基金)?名称',
                    'price':r'成本(?:价)?','quantity':r'持仓(?:数量)?|股票余额|数量|份额',
                    'current_price':r'现价|当前价|最新价|市价','pnl':r'(?:浮动)?盈亏(?:金额)?'}
    for line in text.splitlines():
        tokens=re.split(r'\s+',line.strip())
        mapping={}
        for i,token in enumerate(tokens):
            for key,label in header_aliases.items():
                if re.fullmatch(label,token):mapping[key]=i
        if 'code' in mapping and len(mapping)>=3:
            header=mapping
            continue
        code = re.search(r'(?<!\d)(\d{6})(?!\d)',line)
        if not code:
            continue
        row = dict(code=code[1],instrument_name='',name='',category='stock',price=None,
                   quantity=None,current_price=None,pnl=None,confidence='待核对',source_line=line)
        name = re.search(r'[\u4e00-\u9fffA-Za-z*]{2,20}',line)
        if name:
            row['instrument_name']=row['name']=name[0]
        for key, label in aliases.items():
            match = re.search(r'(?:'+label+r')\s*[:：]?\s*(-?\d[\d,]*(?:\.\d+)?)',line)
            if match:
                row[key]=match[1].replace(',','')
        if header and header.get('code',999)<len(tokens) and tokens[header['code']]==code[1]:
            for key,index in header.items():
                if index>=len(tokens):continue
                value=tokens[index].replace(',','')
                if key=='instrument_name':row['instrument_name']=row['name']=value
                elif key!='code' and re.fullmatch(r'-?\d+(?:\.\d+)?',value):row[key]=value
        row['missing_fields']=[k for k in ('instrument_name','price','quantity') if not row[k]]
        rows.append(row)
    return rows[:100]


def recognize(import_id):
    with connect(True) as db:
        row=db.execute('SELECT * FROM ocr_imports WHERE id=?',(import_id,)).fetchone()
        if not row or row['status'] not in ('queued','failed'):
            return
        db.execute("UPDATE ocr_imports SET status='processing',error=NULL WHERE id=?",(import_id,))
    try:
        import pytesseract
        pytesseract.pytesseract.tesseract_cmd=engine_path()
        with Image.open(row['file_path']) as image:
            gray=ImageOps.grayscale(ImageOps.exif_transpose(image))
            text=pytesseract.image_to_string(gray,lang=os.environ.get('WULE_OCR_LANG','chi_sim+eng'),
                                             config='--psm 6',timeout=90)
        candidates=parse_text(text)
        with connect(True) as db:
            db.execute("UPDATE ocr_imports SET status='review',raw_text=?,candidates=? WHERE id=?",
                       (text,json.dumps(candidates,ensure_ascii=False),import_id))
    except Exception as exc:
        with connect(True) as db:
            db.execute("UPDATE ocr_imports SET status='failed',error=? WHERE id=?",
                       (str(exc)[:1000],import_id))
