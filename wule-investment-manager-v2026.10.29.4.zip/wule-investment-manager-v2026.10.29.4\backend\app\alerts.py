"""结项提醒：按项目设置的盈亏提示线生成通知。

触发时机：交易落账、行情刷新、通知列表读取（兜底）。同一项目同一类型的未读通知只保留一条，已读后再次触发会重新提醒。
"""
from decimal import Decimal, InvalidOperation
from .accounting import project, serialize, money, now

D = Decimal


def check_alerts(db, pid: str | None = None):
    """检测单个项目（或全部活跃项目）的盈亏提示线并写入 notifications。"""
    if pid:
        rows = [project(db, pid)]
    else:
        ids = db.execute("SELECT id FROM projects WHERE status='active'").fetchall()
        rows = [project(db, r['id']) for r in ids]
    for row in rows:
        _check_one(db, row)


def _check_one(db, row):
    thresholds = (('profit', row['alert_profit']), ('loss', row['alert_loss']))
    if not any(threshold for _, threshold in thresholds):
        return
    try:
        # total_pnl 是序列化时计算的派生字段（已实现+浮动），非表列。
        pnl = D(serialize(row)['total_pnl'])
    except (InvalidOperation, TypeError):
        return
    for kind, threshold in thresholds:
        if not threshold:
            continue
        try:
            line = D(threshold)
        except InvalidOperation:
            continue
        hit = pnl >= line if kind == 'profit' else pnl <= -line
        if not hit:
            continue
        dup = db.execute(
            'SELECT 1 FROM notifications WHERE project_id=? AND kind=? AND read_at IS NULL',
            (row['id'], kind)).fetchone()
        if dup:
            continue
        label = '盈利提示线' if kind == 'profit' else '亏损提示线'
        message = (f"项目「{row['name']}」（{row['code']}）当前累计盈亏 {money(pnl)} 元，"
                   f"已{'达到' if kind == 'profit' else '触及'}你设置的{label}（{money(line)} 元），可考虑结项。")
        db.execute(
            "INSERT INTO notifications(project_id,kind,title,message,pnl,created_at) VALUES(?,?,?,?,?,?)",
            (row['id'], kind, f"{'盈利' if kind == 'profit' else '亏损'}提醒 · {row['name']}",
             message, money(pnl), now()))


def save_alerts(db, pid: str, alert_profit: str | None, alert_loss: str | None):
    """设置/清除提示线；传 None 或空串表示清除。"""
    values = {}
    for column, value in (('alert_profit', alert_profit), ('alert_loss', alert_loss)):
        if value is None or str(value).strip() == '':
            values[column] = None
        else:
            line = D(str(value))  # 非法格式抛 InvalidOperation 由接口转 422
            if line < 0:
                raise ValueError('提示线金额不能为负数')
            values[column] = str(line)
    db.execute('UPDATE projects SET alert_profit=?,alert_loss=? WHERE id=?',
               (values['alert_profit'], values['alert_loss'], pid))
    # 设置后立即检测一次（阈值可能已被当前盈亏满足）。
    check_alerts(db, pid)
