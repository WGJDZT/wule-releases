import json
from decimal import Decimal
from pathlib import Path
from .db import connect, DATA
from .accounting import serialize, ledger, now, money


def report_data(filters):
    clauses, params = [], []
    for key in ('category','status'):
        if filters.get(key):
            clauses.append('p.'+key+'=?'); params.append(filters[key])
    where=' WHERE '+' AND '.join(clauses) if clauses else ''
    with connect() as db:
        # All worksheets are read from one SQLite snapshot.
        db.execute('BEGIN')
        projects=[serialize(r) for r in db.execute('SELECT p.* FROM projects p'+where,params)]
        project_ids={p['id'] for p in projects}
        trade_clauses=list(clauses)
        trade_params=list(params)
        if filters.get('starts_on'):
            trade_clauses.append('o.created_at>=?');trade_params.append(filters['starts_on'])
        if filters.get('ends_on'):
            trade_clauses.append('substr(o.created_at,1,10)<=?');trade_params.append(filters['ends_on'])
        tw=' WHERE '+' AND '.join(trade_clauses) if trade_clauses else ''
        trades=[dict(r) for r in db.execute('SELECT o.* FROM operations o JOIN projects p ON p.id=o.project_id'+tw+' ORDER BY o.id',trade_params)]
        goals=[dict(r) for r in db.execute('SELECT * FROM goals') if not r['project_id'] or r['project_id'] in project_ids]
        for g in goals:
            pnl=Decimal(ledger(db)['pnl']) if not g['project_id'] else sum((Decimal(p['quantity'])*Decimal(p['current_price'])-Decimal(p['cost_basis'])+Decimal(p['realized_pnl']) for p in projects if p['id']==g['project_id']),Decimal(0))
            pnl=Decimal(money(pnl))
            g['current_pnl']=money(pnl-Decimal(g['baseline_pnl']))
            g['completion_percent']=str((pnl-Decimal(g['baseline_pnl']))/Decimal(g['target'])*100)
        strategies=[dict(r) for r in db.execute('SELECT s.*,sp.project_id FROM strategies s LEFT JOIN strategy_projects sp ON s.id=sp.strategy_id')
                    if r['project_id'] is None or r['project_id'] in project_ids]
        total_pnl=sum((Decimal(p['quantity'])*Decimal(p['current_price'])-Decimal(p['cost_basis'])+Decimal(p['realized_pnl']) for p in projects),Decimal(0))
        principal=sum((Decimal(p['invested']) for p in projects),Decimal(0))
        adjustment=Decimal(ledger(db)['adjustments']) if not filters.get('category') and not filters.get('status') else Decimal(0)
        summary=[{'指标':'累计买入本金','金额':money(principal)}, {'指标':'总资产（持仓+累计卖出回款）','金额':money(principal+total_pnl+adjustment)},
                 {'指标':'项目累计盈亏','金额':money(total_pnl)}, {'指标':'总账手动修正','金额':money(adjustment)},
                 {'指标':'总盈亏（含修正）','金额':money(total_pnl+adjustment)},
                 {'指标':'区间已实现盈亏','金额':money(sum((Decimal(t['realized_pnl']) for t in trades),Decimal(0)))},
                 {'指标':'说明','金额':'持仓为导出时点快照；日期筛选仅作用于交易明细和区间已实现盈亏。目标按当前项目快照显示。'}]
        distribution={}
        for p in projects:
            distribution[p['category']]=distribution.get(p['category'],Decimal(0))+Decimal(p['quantity'])*Decimal(p['current_price'])
        holdings=[{'类别':k,'市值':money(v)} for k,v in distribution.items()]
        categories={r['id']:r['name'] for r in db.execute('SELECT id,name FROM categories')}
    kind_names={'open':'开仓','buy':'加仓','sell':'减仓','close':'结项'}
    period_names={'year':'年度','quarter':'季度','month':'月度'}
    def columns(rows,fields):
        return [{label:row.get(key,'') for key,label in fields} for row in rows]
    for p in projects:
        p['category']=categories.get(p['category'],p['category'])
        p['status']='进行中' if p['status']=='active' else '已结项'
        p['cost_price']=str(Decimal(p['cost_price']).quantize(Decimal('.000001')))
    for t in trades:t['kind']=kind_names[t['kind']]
    for h in holdings:h['类别']=categories.get(h['类别'],h['类别'])
    for g in goals:
        g['period']=period_names[g['period']]
        g['project_id']=g['project_id'] or '总账单'
        g['completion_percent']=f"{Decimal(g['completion_percent']):.2f}%"
    for s in strategies:
        s['tags']='、'.join(json.loads(s['tags']))
        s['project_id']=s.get('project_id') or '未关联'
    return {'盈亏汇总':summary,
            '项目持仓':columns(projects,[('id','项目编号'),('name','项目名称'),('category','资产类别'),('code','标的代码'),('instrument_name','标的名称'),
                ('cost_price','成本价'),('quantity','持仓份额'),('current_price','当前价'),('market_value','持仓市值'),('unrealized_pnl','浮动盈亏'),('realized_pnl','已实现盈亏'),('total_pnl','累计盈亏'),('status','项目状态')]),
            '交易明细':columns(trades,[('project_id','项目编号'),('kind','操作类型'),('price','成交价'),('quantity','数量'),('fee','手续费'),('realized_pnl','实现盈亏'),('note','操作备注'),('created_at','操作时间')]),
            '持仓分布':holdings,
            '目标达成':columns(goals,[('name','目标名称'),('period','周期'),('project_id','目标范围'),('target','盈利目标'),('current_pnl','当前盈利'),('completion_percent','完成率'),('starts_on','开始日期'),('ends_on','截止日期')]),
            '策略关联':columns(strategies,[('name','策略名称'),('tags','策略标签'),('project_id','关联项目'),('trigger_conditions','触发条件'),('buy_logic','买入逻辑'),('sell_logic','卖出逻辑'),('position_rules','仓位规则'),('stop_loss','止损规则'),('review','复盘结论')])}


def export_report(report_id):
    with connect(True) as db:
        record=db.execute('SELECT * FROM reports WHERE id=?',(report_id,)).fetchone()
        db.execute("UPDATE reports SET status='processing' WHERE id=?",(report_id,))
    try:
        data=report_data(json.loads(record['filters']))
        folder=DATA/'reports';folder.mkdir(parents=True,exist_ok=True)
        target=folder/(report_id+'.'+record['format'])
        if record['format']=='xlsx':
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill
            from openpyxl.utils import get_column_letter
            wb=Workbook(write_only=False);wb.remove(wb.active)
            for title,rows in data.items():
                ws=wb.create_sheet(title)
                if not rows:
                    ws.append(['暂无记录']);continue
                keys=list(rows[0]);ws.append(keys)
                for row in rows:
                    # Text is forced literal, protecting exports from spreadsheet formula injection.
                    ws.append([str(row.get(k,'')) if row.get(k) is not None else '' for k in keys])
                    for cell in ws[ws.max_row]:
                        cell.data_type='s'
                for cell in ws[1]:
                    cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='174C3C')
                for col in range(1,len(keys)+1):
                    ws.column_dimensions[get_column_letter(col)].width=22
                ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
            wb.save(target)
        else:
            filters=json.loads(record['filters'])
            with connect() as db:cat_names={r['id']:r['name'] for r in db.execute('SELECT id,name FROM categories')}
            category=cat_names.get(filters.get('category'),'全部类别')
            status={'active':'进行中','closed':'已结项'}.get(filters.get('status'),'全部状态')
            date_range=f"{filters.get('starts_on') or '不限起始'} 至 {filters.get('ends_on') or '不限结束'}"
            lines=['我悟了投资管理有限公司 · 投资财报', '生成时间：'+now()[:19].replace('T',' '),f'筛选：{category} / {status} / {date_range}']
            def wrap_fields(row):
                line=''
                for key,value in row.items():
                    part=f'{key}：{value if value is not None else ""}'
                    if line and len(line)+len(part)+3>64:
                        yield line;line=''
                    while len(part)>64:
                        yield part[:64];part=part[64:]
                    line=line+' | '+part if line else part
                if line:yield line
            for title,rows in data.items():
                lines += ['', '【'+title+'】']
                for row in rows:
                    lines.extend(wrap_fields(row))
                    if len(row)>4:lines.append('')
                if not rows:lines.append('暂无记录')
            if record['format']=='pdf':
                from reportlab.pdfgen import canvas
                from reportlab.pdfbase import pdfmetrics
                from reportlab.pdfbase.cidfonts import UnicodeCIDFont
                pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
                c=canvas.Canvas(str(target),pagesize=(842,595));y=529;page=1
                c.setTitle('我悟了投资财报');c.setAuthor('我悟了投资管理有限公司')
                def header():
                    c.setFillColorRGB(.12,.31,.23);c.setFont('STSong-Light',16)
                    c.drawString(32,562,'我悟了 · 投资财报');c.setStrokeColorRGB(.8,.86,.79);c.line(32,548,810,548)
                def footer():
                    c.setFillColorRGB(.5,.56,.48);c.setFont('STSong-Light',9)
                    c.drawString(32,23,'我悟了投资管理有限公司');c.drawRightString(810,23,f'第 {page} 页')
                header()
                for line in lines:
                    if y<48:footer();c.showPage();page+=1;header();y=529
                    heading=line.startswith('【')
                    c.setFont('STSong-Light',12 if heading else 10)
                    c.setFillColorRGB(*((.12,.31,.23) if heading else (.22,.27,.23)))
                    c.drawString(32,y,line);y-=20 if heading else 16
                footer()
                c.save()
            else:
                from PIL import Image, ImageDraw, ImageFont
                import os
                font_path=os.environ.get('WULE_REPORT_FONT','C:/Windows/Fonts/msyh.ttc')
                font=ImageFont.truetype(font_path,18)
                # Image export caps height; use PDF/XLSX for arbitrarily large reports.
                if len(lines)>1500:raise ValueError('图片财报超过1500行，请缩小日期范围或导出Excel/PDF')
                image=Image.new('RGB',(1500,max(250,80+len(lines)*30)),'#f5f7f3')
                draw=ImageDraw.Draw(image)
                for i,line in enumerate(lines):draw.text((32,30+i*30),line,font=font,fill='#173d33')
                image.save(target)
        with connect(True) as db:
            db.execute("UPDATE reports SET status='ready',file_path=? WHERE id=?",(str(target),report_id))
    except Exception as exc:
        with connect(True) as db:
            db.execute("UPDATE reports SET status='failed',error=? WHERE id=?",(str(exc)[:1000],report_id))
