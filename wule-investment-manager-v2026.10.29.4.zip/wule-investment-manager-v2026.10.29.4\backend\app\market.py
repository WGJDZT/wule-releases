"""市场洞悉：A股行业板块、核心指数、个股涨跌家数（新浪全量+东财备源）、美股产业主题。"""
import json
import re
import time as _time
import random
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, time, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
import httpx
from .accounting import now, TZ

_cache = {'at': 0.0, 'data': None}
CACHE_TTL = 300  # 5 分钟

# —— 四大核心指数（腾讯 qt.gtimg.cn 批量查询）——
A_INDEXES = [
    ('sh000001', '上证指数'),
    ('sz399001', '深证成指'),
    ('sz399006', '创业板指'),
    ('sh000688', '科创50'),
]

# —— 美股 26 个产业主题 ——
US_SECTORS = [
    ('AIQ', 'AI算力'), ('COHR', 'CPO'), ('SMH', '半导体'), ('MU', '存储'),
    ('SRVR', '数据中心'), ('CLOU', '云计算'), ('UFO', '商业航天'), ('IRDM', '卫星'),
    ('BOTZ', '机器人'), ('DRIV', '自动驾驶'), ('NLR', '核电'), ('GRID', '电网'),
    ('ITA', '军工'), ('TAN', '光伏'), ('LIT', '锂电池'), ('XLE', '油气'),
    ('COPX', '铜/有色'), ('GDX', '黄金矿业'), ('XLF', '银行金融'), ('XBI', '生物医药'),
    ('XLY', '消费'), ('REMX', '稀土'), ('XLC', '通信设备'), ('QTUM', '量子计算'),
    ('BLOK', '区块链'), ('ARTY', 'AI应用'),
]


# —— session label ——
def a_session_label(dt: datetime) -> str:
    if dt.weekday() < 5:
        t = dt.time()
        if time(9, 30) <= t <= time(15, 0):
            return '今日盘中'
        if t > time(15, 0):
            return '今日收盘'
    return '上一交易日收盘'


def _us_eastern(dt_utc: datetime) -> datetime:
    year = dt_utc.year
    march = datetime(year, 3, 8, tzinfo=timezone.utc)
    dst_start = march + timedelta(days=(6 - march.weekday()) % 7)
    nov = datetime(year, 11, 1, tzinfo=timezone.utc)
    dst_end = nov + timedelta(days=(6 - nov.weekday()) % 7)
    offset = -4 if dst_start <= dt_utc < dst_end else -5
    return dt_utc.astimezone(timezone(timedelta(hours=offset)))


def us_session_label(dt_utc: datetime) -> str:
    et = _us_eastern(dt_utc)
    if et.weekday() < 5:
        t = et.time()
        if time(9, 30) <= t <= time(16, 0):
            return '今日盘中'
        if t > time(16, 0):
            return '今日收盘'
    return '上一交易日收盘'


def _prev_trading_day(d):
    d -= timedelta(days=1)
    while d.weekday() >= 5:
        d -= timedelta(days=1)
    return d


# —— 腾讯协议解析工具 ——
def _pct(price, prev):
    if not prev or Decimal(prev) <= 0:
        return None
    return str(((Decimal(price) / Decimal(prev) - 1) * 100).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))


def _parse_qt_line(line):
    """解析 qt.gtimg.cn 的 ~ 分隔行情行，返回字段列表或 None。"""
    if '"' not in line:
        return None
    body = line.split('"')[1]
    f = body.split('~')
    return f if len(f) >= 5 else None


# —— A股行业板块 ——
def fetch_a_sectors():
    """腾讯行业板块排行：涨幅前20 + 跌幅后6 = 26 项。"""
    r = httpx.get('https://proxy.finance.qq.com/ifzqgtimg/appstock/app/mktHs/rank',
                  params={'l': 100, 'p': 1, 't': '01/averatio'},
                  headers={'Referer': 'https://gu.qq.com/'}, timeout=10)
    r.raise_for_status()
    payload = r.json()
    if payload.get('code') != 0:
        raise ValueError('腾讯板块源返回异常：' + str(payload.get('msg'))[:80])
    items = []
    for d in payload.get('data') or []:
        name = re.sub(r'[ⅠⅡⅢ]+$', '', d.get('bd_name', '')).strip()
        try:
            pct = Decimal(str(d.get('bd_zdf')))
        except Exception:
            continue
        items.append({'name': name, 'change_pct': str(pct)})
    top = items[:20]
    tail = [x for x in items[-6:] if x not in top]
    return top + tail


# —— A股四大核心指数行情 ——
def fetch_a_indexes():
    """腾讯 qt.gtimg.cn 批量查询四大指数。"""
    codes = ','.join(c for c, _ in A_INDEXES)
    r = httpx.get('https://qt.gtimg.cn/q=' + codes,
                  headers={'Referer': 'https://gu.qq.com/'}, timeout=10)
    r.raise_for_status()
    r.encoding = 'gb18030'
    items = []
    for ln in r.text.split(';'):
        ln = ln.strip()
        if not ln or '"' not in ln:
            continue
        f = _parse_qt_line(ln)
        if not f:
            continue
        # 行头形如 v_sh000001=，从中提取 code
        prefix_end = ln.find('=')
        if prefix_end < 0:
            continue
        raw_key = ln[:prefix_end]  # v_sh000001
        code = raw_key[2:]  # 去掉 v_ → sh000001
        if code not in dict(A_INDEXES):
            continue
        try:
            price = Decimal(f[3])
            prev = Decimal(f[4])
            change = Decimal(f[31]) if len(f) > 31 and f[31] else price - prev
            pct = _pct(f[3], f[4])
            items.append({
                'code': code,
                'name': dict(A_INDEXES)[code],
                'price': str(price),
                'prev_close': str(prev),
                'change': str(change),
                'change_pct': pct,
            })
        except Exception:
            continue
    if not items:
        raise ValueError('A股核心指数行情全部获取失败')
    return items


# —— A股个股涨跌家数：新浪全量扫描（主源） ——
_SINA_LIST = ('https://vip.stock.finance.sina.com.cn/quotes_service/api/'
              'json_v2.php/Market_Center.getHQNodeData')
_SINA_COUNT = ('https://vip.stock.finance.sina.com.cn/quotes_service/api/'
               'json_v2.php/Market_Center.getHQNodeStockCount')
_SINA_HEADERS = {'User-Agent': 'Mozilla/5.0',
                 'Referer': 'https://finance.sina.com.cn/'}
_SINA_PAGE_SIZE = 100


def _sina_page(page_no, retries=2):
    for att in range(retries + 1):
        try:
            r = httpx.get(_SINA_LIST,
                          params={'page': page_no, 'num': _SINA_PAGE_SIZE,
                                  'sort': 'changepercent', 'asc': 0,
                                  'node': 'hs_a', 'symbol': '', '_s_r_a': 'page'},
                          headers=_SINA_HEADERS, timeout=15)
            r.raise_for_status()
            return json.loads(r.text) or []
        except Exception:
            if att < retries:
                time.sleep(random.uniform(0.2, 0.5))
    return []


def _fetch_a_updown_sina():
    """新浪沪深京 A 股全量扫描（约 56 页、并发 4），逐只统计上涨/下跌/平盘家数。"""
    r = httpx.get(_SINA_COUNT, params={'node': 'hs_a'}, headers=_SINA_HEADERS, timeout=10)
    r.raise_for_status()
    total = int(re.sub(r'\D', '', r.text) or 0)
    if total <= 0:
        raise ValueError('新浪A股总数获取失败')
    pages = (total + _SINA_PAGE_SIZE - 1) // _SINA_PAGE_SIZE
    rows = []
    with ThreadPoolExecutor(max_workers=4) as ex:
        for arr in ex.map(_sina_page, range(1, pages + 1)):
            rows.extend(arr)
    got = len(rows)
    if got < total * 0.95:
        raise ValueError(f'新浪个股扫描不完整：{got}/{total}')
    ups = downs = flats = nulls = 0
    for x in rows:
        try:
            p = float(x.get('changepercent'))
        except (TypeError, ValueError):
            p = None
        if p is None:
            nulls += 1
        elif p > 0:
            ups += 1
        elif p < 0:
            downs += 1
        else:
            flats += 1
    return {'up': ups, 'down': downs, 'flat': flats, 'null': nulls,
            'source': 'sina', 'covered': got, 'total': total}


# —— 东财 clist 全量扫描（备源） ——
_EASTMONEY_UA = 'Python-urllib/3.x'
_EM_TOTAL = 5926  # A股总数（沪深京）
_EM_PAGE_SIZE = 100
_EM_MIN_COVERAGE = 0.90  # 覆盖率 ≥ 90% 才信


def _fetch_clist_page(pn, retries=3):
    for att in range(retries + 1):
        try:
            r = httpx.get('https://push2.eastmoney.com/api/qt/clist/get',
                          params={'pn': pn, 'pz': _EM_PAGE_SIZE, 'po': 1, 'np': 1,
                                  'ut': 'bd1d9ddb04089700cf9c27f6f7426281',
                                  'fltt': 2, 'invt': 2, 'fid': 'f3',
                                  'fs': 'm:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23,m:0+t:81+s:2048',
                                  'fields': 'f3'},
                          headers={'User-Agent': _EASTMONEY_UA}, timeout=15)
            d = r.json()
            return d.get('data', {}).get('diff', [])
        except Exception:
            if att < retries:
                time.sleep(random.uniform(0.2, 0.6))
            else:
                return []


def _fetch_a_updown_em():
    """东财 clist 全量扫描涨跌家数；覆盖率 ≥ 60% 才返回，否则返回 None。"""
    pages = (_EM_TOTAL + _EM_PAGE_SIZE - 1) // _EM_PAGE_SIZE  # 5926 / 100 = 60
    all_items = []
    with ThreadPoolExecutor(max_workers=6) as ex:
        futures = {ex.submit(_fetch_clist_page, p): p for p in range(1, pages + 1)}
        for fut in as_completed(futures):
            all_items.extend(fut.result())
    got = len(all_items)
    if got / _EM_TOTAL < _EM_MIN_COVERAGE:
        return None  # 样本不够，不信
    ups = downs = flats = nulls = 0
    for x in all_items:
        v = x.get('f3')
        try:
            p = float(v) if v not in (None, '', '-') else None
        except Exception:
            p = None
        if p is None:
            nulls += 1
        elif p > 0:
            ups += 1
        elif p < 0:
            downs += 1
        else:
            flats += 1
    return {'up': ups, 'down': downs, 'flat': flats, 'null': nulls,
            'source': 'eastmoney', 'covered': got, 'total': _EM_TOTAL}


def fetch_a_updown():
    """个股涨跌家数：新浪全量为主，东财全量为备；都失败返回 None（前端隐藏该区块）。"""
    for fn in (_fetch_a_updown_sina, _fetch_a_updown_em):
        try:
            result = fn()
            if result:
                return result
        except Exception:
            continue
    return None


# —— 美股并发取数 ——
def _us_quote(client, code):
    r = client.get('https://qt.gtimg.cn/q=us' + code, headers={'Referer': 'https://gu.qq.com/'})
    r.raise_for_status()
    r.encoding = 'gb18030'
    f = _parse_qt_line(r.text)
    if not f or len(f) < 5 or not f[3] or not f[4]:
        raise ValueError(f'美股行情字段缺失：{code}')
    pct = _pct(f[3], f[4])
    if pct is None:
        raise ValueError(f'美股行情价格异常：{code}')
    return pct


def fetch_us_sectors():
    codes = [c for c, _ in US_SECTORS]
    with httpx.Client(timeout=8) as client:
        with ThreadPoolExecutor(max_workers=8) as pool:
            pcts = list(pool.map(lambda c: _safe_us_quote(client, c), codes))
    items = [{'name': cn, 'code': code, 'change_pct': pct}
             for (code, cn), pct in zip(US_SECTORS, pcts) if pct is not None]
    if not items:
        raise ValueError('美股产业行情全部获取失败')
    return items


def _safe_us_quote(client, code):
    try:
        return _us_quote(client, code)
    except Exception:
        return None


# —— 主入口 ——
def market_insight(force=False):
    if not force and _cache['data'] and _time.time() - _cache['at'] < CACHE_TTL:
        return _cache['data']
    now_local = datetime.now(TZ)
    now_utc = datetime.now(timezone.utc)
    et = _us_eastern(now_utc)
    a_label = a_session_label(now_local)
    a_date = now_local.date() if a_label.startswith('今日') else _prev_trading_day(now_local.date())
    us_label = us_session_label(now_utc)
    us_date = et.date() if us_label.startswith('今日') else _prev_trading_day(et.date())

    errors = []

    def _try(label, fn):
        try:
            return fn(), None
        except Exception as exc:
            return None, {'market': label, 'error': str(exc)[:200]}

    a_sectors, e1 = _try('a_share_sectors', fetch_a_sectors)
    a_indexes, e2 = _try('a_share_indexes', fetch_a_indexes)
    a_updown, e3 = _try('a_updown', fetch_a_updown)
    us_sectors, e4 = _try('us', fetch_us_sectors)
    errors.extend(x for x in [e1, e2, e3, e4] if x)

    data = {
        'a_share': {
            'label': a_label, 'date': a_date.isoformat(),
            'sectors': a_sectors or [],
            'indexes': a_indexes or [],
            'updown': a_updown,
        },
        'us': {'label': us_label, 'date': us_date.isoformat(), 'items': us_sectors or []},
        'errors': errors, 'fetched_at': now(),
    }
    _cache.update(at=_time.time(), data=data)
    return data
