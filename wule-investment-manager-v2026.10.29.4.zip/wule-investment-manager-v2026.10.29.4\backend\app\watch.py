"""股票盯盘：自选列表、实时/分时/日 K 行情、涨跌幅阈值提醒。

数据源全部为 A 股六位代码：
- 实时 tick：腾讯财经 qt.gtimg.cn（与 quotes.py 同源，60s 缓存）
- 日 K（前复权）：东方财富 push2his.eastmoney.com/api/qt/stock/kline/get，失败回退腾讯 fqkline
- 盘中分时（每分钟，仅交易日）：东方财富 .../trends2/get，失败回退腾讯 minute/query

自选持久化在 settings 表：key='watchlist'，value 为 JSON 数组：
    [{'code':'600825','name':'新华传媒','upper_pct':3.0,'lower_pct':-3.0,'enabled':true}]

告警：涨跌绝对值触发 → 写 notifications 表（kind='watch'），
      同 (code, kind) 300s 冷却去重，避免刷屏。
"""
import json
import re
import time
from decimal import Decimal
from datetime import datetime, timedelta
from pathlib import Path

import httpx

from .db import connect
from .quotes import symbol as _symbol, fetch_quote, quote_at
from .accounting import now, TZ

WATCH_KEY = 'watchlist'
ALERT_COOLDOWN = 300  # 秒
MARKETS = {'6': '1', '5': '1', '9': '1', '0': '0', '3': '0', '1': '0', '2': '0', '4': '0', '8': '0'}
EASTMONEY = 'https://push2his.eastmoney.com/api/qt/stock'


# ---------- 自选列表 ----------
def load() -> list[dict]:
    with connect() as db:
        row = db.execute('SELECT value FROM settings WHERE key=?', (WATCH_KEY,)).fetchone()
    if not row:
        return []
    try:
        data = json.loads(row['value'])
        assert isinstance(data, list)
        return [_normalize(x) for x in data]
    except (json.JSONDecodeError, AssertionError, TypeError):
        return []


def _normalize(item: dict) -> dict:
    code = str(item.get('code', '')).strip()
    if not re.fullmatch(r'\d{6}', code):
        raise ValueError('股票代码需为六位数字')
    name = str(item.get('name', '') or '').strip()
    return {
        'code': code,
        'name': name,
        'upper_pct': float(item.get('upper_pct') or 0),
        'lower_pct': float(item.get('lower_pct') or 0),
        'enabled': bool(item.get('enabled', True)),
    }


def save(list_items: list[dict]) -> list[dict]:
    normalized = [_normalize(x) for x in list_items]
    normalized.sort(key=lambda x: x['code'])
    payload = json.dumps(normalized, ensure_ascii=False)
    with connect(True) as db:
        db.execute(
            'INSERT INTO settings(key,value) VALUES(?,?) '
            'ON CONFLICT(key) DO UPDATE SET value=excluded.value',
            (WATCH_KEY, payload))
    return normalized


def upsert(code: str, **kwargs) -> list[dict]:
    code = code.strip()
    if not re.fullmatch(r'\d{6}', code):
        raise ValueError('股票代码需为六位数字')
    items = load()
    for i, x in enumerate(items):
        if x['code'] == code:
            items[i].update({k: v for k, v in kwargs.items() if v is not None})
            break
    else:
        items.append({'code': code, 'name': kwargs.get('name', ''),
                      'upper_pct': kwargs.get('upper_pct', 0) or 0,
                      'lower_pct': kwargs.get('lower_pct', 0) or 0,
                      'enabled': kwargs.get('enabled', True)})
    return save(items)


def remove(code: str) -> list[dict]:
    code = code.strip()
    items = [x for x in load() if x['code'] != code]
    return save(items)


# ---------- 行情查询 ----------
def _market_for(code: str) -> str:
    return '1' if code[0] in ('5', '6', '9') else '0'


def _eastmoney_headers():
    return {'Referer': 'https://quote.eastmoney.com/',
            'User-Agent': 'Mozilla/5.0'}


def _eastmoney_fetch(url: str, params: dict) -> dict:
    """东方财富接口，3 次重试（断连/超时）。"""
    for attempt in range(3):
        try:
            r = httpx.get(url, params=params, timeout=10, headers=_eastmoney_headers())
            r.raise_for_status()
            return r.json()
        except (httpx.RemoteProtocolError, httpx.TimeoutException, httpx.ConnectError):
            if attempt == 2:
                raise
            time.sleep(0.4 * (attempt + 1))


def _tencent_kline(code: str, limit: int) -> list[dict]:
    """腾讯财经前复权日 K（东方财富断连时的兜底源）。"""
    prefix = 'sh' if _market_for(code) == '1' else 'sz'
    r = httpx.get('https://web.ifzq.gtimg.cn/appstock/app/fqkline/get',
                  params={'param': f'{prefix}{code},day,,,{limit},qfq'},
                  timeout=10,
                  headers={'Referer': 'https://gu.qq.com/',
                           'User-Agent': 'Mozilla/5.0'})
    r.raise_for_status()
    node = (r.json().get('data') or {}).get(f'{prefix}{code}') or {}
    out = []
    for row in node.get('qfqday') or node.get('day') or []:
        if len(row) < 6:
            continue
        out.append(dict(date=row[0], open=float(row[1]), close=float(row[2]),
                        high=float(row[3]), low=float(row[4]),
                        volume=int(float(row[5])), turnover=0.0))
    return out


def kline(code: str, limit: int = 30) -> list[dict]:
    """前复权日 K：优先东方财富，失败或无数据时回退腾讯。"""
    secid = f"{_market_for(code)}.{code}"
    params = dict(secid=secid, fields1='f1,f2,f3,f4,f5,f6',
                  fields2='f51,f52,f53,f54,f55,f56,f57',
                  klt=101, fqt=1, end='20500101', lmt=limit)
    try:
        raw = _eastmoney_fetch(f'{EASTMONEY}/kline/get', params).get('data')
    except Exception:
        raw = None
    out = []
    for line in (raw or {}).get('klines', []) or []:
        parts = line.split(',')
        if len(parts) < 7:
            continue
        out.append(dict(date=parts[0], open=float(parts[1]), close=float(parts[2]),
                        high=float(parts[3]), low=float(parts[4]),
                        volume=int(float(parts[5])), turnover=float(parts[6])))
    if out:
        return out
    try:
        return _tencent_kline(code, limit)
    except Exception:
        return []


def _tencent_minute(code: str) -> list[dict]:
    """腾讯财经盘中分时（东方财富断连时的兜底源）。

    原始行格式：'HHMM 价格 累计成交量(手) 累计成交额(元)'，逐行换算成单分钟量。
    """
    prefix = 'sh' if _market_for(code) == '1' else 'sz'
    r = httpx.get('https://web.ifzq.gtimg.cn/appstock/app/minute/query',
                  params={'code': f'{prefix}{code}'}, timeout=10,
                  headers={'Referer': 'https://gu.qq.com/',
                           'User-Agent': 'Mozilla/5.0'})
    r.raise_for_status()
    node = (r.json().get('data') or {}).get(f'{prefix}{code}') or {}
    day = datetime.now(TZ).strftime('%Y-%m-%d')
    out = []
    last_vol = 0
    for row in (node.get('data') or {}).get('data') or []:
        parts = str(row).split()
        if len(parts) < 4 or len(parts[0]) != 4:
            continue
        price = float(parts[1])
        cum_vol = int(float(parts[2]))
        cum_amt = float(parts[3])
        vol = max(cum_vol - last_vol, 0)
        last_vol = cum_vol
        avg = (cum_amt / (cum_vol * 100)) if cum_vol else price
        out.append(dict(time=f'{day} {parts[0][:2]}:{parts[0][2:]}',
                        price=price, open=price, high=price, low=price,
                        volume=vol, avg=round(avg, 4)))
    return out


def minute(code: str, limit: int = 480) -> list[dict]:
    """盘中分时：优先东方财富，失败或无数据时回退腾讯。"""
    secid = f"{_market_for(code)}.{code}"
    params = dict(secid=secid, fields1='f1,f2,f3,f4,f5,f6',
                  fields2='f51,f52,f53,f54,f55,f56,f57,f58',
                  klt=1, fqt=1, lmt=limit)
    try:
        data = _eastmoney_fetch(f'{EASTMONEY}/trends2/get', params).get('data') or {}
    except Exception:
        data = {}
    out = []
    for line in data.get('trends', []) or []:
        parts = line.split(',')
        if len(parts) < 8:
            continue
        out.append(dict(time=parts[0], price=float(parts[2]), open=float(parts[1]),
                        high=float(parts[3]), low=float(parts[4]),
                        volume=int(float(parts[5])), avg=float(parts[7])))
    if out:
        return out
    try:
        return _tencent_minute(code)[-limit:]
    except Exception:
        return []


def snapshot(code: str, force=False) -> dict:
    """实时快照：腾讯财经（复用 quotes.py）+ 涨跌幅派生。"""
    try:
        q = fetch_quote(code, 'stock', force=force)
    except Exception as e:
        return {'code': code, 'error': str(e)[:120]}
    price = Decimal(q['price'])
    prev = Decimal(q['previous_close']) if q.get('previous_close') and Decimal(q['previous_close']) > 0 else None
    chg = None
    pct = None
    if prev:
        chg = (price - prev)
        pct = (chg / prev * 100)
    return {
        'code': code,
        'name': q.get('name', ''),
        'price': str(price),
        'previous_close': str(prev) if prev else None,
        'change': str(chg) if chg is not None else None,
        'change_pct': f'{pct:.2f}' if pct is not None else None,
        'market_at': q.get('market_at'),
        'fetched_at': q.get('fetched_at'),
    }


def detail(code: str, force=False) -> dict:
    """聚合：实时快照 + 日 K + 盘中分时 + 用户阈值。

    东方财富接口偶发断连时，日 K / 分时降级为空列表，实时快照仍然返回，
    避免整个详情页 500（前端图表区留空，刷新即可重试）。
    """
    items = load()
    w = next((x for x in items if x['code'] == code), None)
    if not w:
        raise ValueError(f'{code} 未加入自选股')
    snap = snapshot(code, force=force)
    if 'error' in snap:
        return {'code': code, 'error': snap['error'], 'watch': w}
    try:
        bars = kline(code, 60)
    except Exception:
        bars = []
    try:
        ticks = minute(code, 480)
    except Exception:
        ticks = []
    return {
        **snap,
        'watch': w,
        'kline': bars,
        'minute': ticks,
    }


# ---------- 涨跌幅阈值告警 ----------
def _last_alert_seconds(code: str, kind: str) -> int:
    with connect() as db:
        row = db.execute(
            '''SELECT MAX(created_at) AS c FROM notifications
               WHERE code=? AND kind=? AND read_at IS NULL''',
            (code, kind)).fetchone()
    if not row or not row['c']:
        return 10**9
    try:
        t = datetime.fromisoformat(row['c'].replace('Z', '+00:00'))
    except ValueError:
        return 10**9
    return (datetime.now(TZ) - t).total_seconds()


def check_watch_alerts() -> list[dict]:
    """遍历启用的自选，按阈值检测；冷却期内跳过。返回本轮命中。"""
    items = [x for x in load() if x.get('enabled')]
    hits = []
    for w in items:
        try:
            snap = snapshot(w['code'])
        except Exception:
            continue
        if 'error' in snap or snap.get('change_pct') is None:
            continue
        pct = Decimal(snap['change_pct'])
        code = w['code']
        pct_str = snap['change_pct']
        if w['upper_pct'] and pct >= Decimal(str(w['upper_pct'])):
            if _last_alert_seconds(code, 'watch_up') > ALERT_COOLDOWN:
                hits.append(_insert(code, snap['name'], 'watch_up', pct_str, w['upper_pct'], '触发上涨阈值'))
        if w['lower_pct'] and pct <= Decimal(str(w['lower_pct'])):
            if _last_alert_seconds(code, 'watch_down') > ALERT_COOLDOWN:
                hits.append(_insert(code, snap['name'], 'watch_down', pct_str, w['lower_pct'], '触发下跌阈值'))
    return hits


def _insert(code, name, kind, pct, threshold, note) -> dict:
    with connect(True) as db:
        db.execute(
            '''INSERT INTO notifications(kind,project_id,title,message,pnl,created_at,read_at,code)
               VALUES(?,?,?,?,?,?,?,?)''',
            (kind, None, f'{name}({code}) {note}',
             f'当前涨跌幅 {pct}%，阈值 {threshold}%', pct, now(), None, code))
    return {'code': code, 'kind': kind, 'pct': pct}
