from datetime import date, datetime, timedelta
from decimal import Decimal
from fastapi import HTTPException
from .accounting import D, TZ, money, now, project, trade
from .models import DipPlanCreate, OperationCreate

DAYS = {'weekly': 7, 'biweekly': 14}


def _advance(day: date, period: str) -> date:
    if period in DAYS:
        return day + timedelta(days=DAYS[period])
    # monthly：同日进位，月末则 clamp 到目标月最后一天。
    year, month = day.year + (day.month == 12), (day.month % 12) + 1
    last = (date(year + (month == 12), (month % 12) + 1, 1) - timedelta(days=1)).day
    return date(year, month, min(day.day, last))


def create_plan(db, pid: str, data: DipPlanCreate):
    row = project(db, pid)
    if row['category'] == 'settle':
        raise HTTPException(422, '平账项目不支持定投')
    if row['status'] == 'closed':
        raise HTTPException(409, '已结项项目不能新建定投计划')
    if data.start_date < datetime.now(TZ).date():
        raise HTTPException(422, '首次执行日期不能早于今天')
    cur = db.execute(
        'INSERT INTO investment_plans(project_id,amount,price,period,next_run,active,created_at) VALUES(?,?,?,?,?,1,?)',
        (pid, str(data.amount), str(data.price), data.period, data.start_date.isoformat(), now()))
    return get_plan(db, cur.lastrowid)


def get_plan(db, plan_id: int):
    row = db.execute('SELECT * FROM investment_plans WHERE id=?', (plan_id,)).fetchone()
    if not row:
        raise HTTPException(404, '定投计划不存在')
    return dict(row)


def list_plans(db, pid: str):
    project(db, pid)
    return [dict(r) for r in db.execute(
        'SELECT * FROM investment_plans WHERE project_id=? ORDER BY id DESC', (pid,))]


def stop_plan(db, pid: str, plan_id: int):
    row = get_plan(db, plan_id)
    if row['project_id'] != pid:
        raise HTTPException(404, '定投计划不属于该项目')
    db.execute('UPDATE investment_plans SET active=0 WHERE id=?', (plan_id,))
    return get_plan(db, plan_id)


def run_due_plans(db, today: date | None = None) -> int:
    """执行到期的定投计划（含漏跑补齐），返回执行笔数。调用方持有写事务。"""
    today = today or datetime.now(TZ).date()
    due = db.execute(
        'SELECT * FROM investment_plans WHERE active=1 AND next_run<=? ORDER BY id', (today.isoformat(),)).fetchall()
    executed = 0
    for plan in due:
        row = db.execute('SELECT * FROM projects WHERE id=?', (plan['project_id'],)).fetchone()
        if not row or row['status'] != 'active':
            continue
        run_day = date.fromisoformat(plan['next_run'])
        while run_day <= today:
            amount, price = D(plan['amount']), D(plan['price'])
            quantity = (amount / price).quantize(D('0.000001'))
            current = db.execute('SELECT version FROM projects WHERE id=?', (plan['project_id'],)).fetchone()
            # 成交时间：历史补记为当日 09:30；当天执行则取当前时刻，避免"未来时间"校验拒绝。
            moment = (datetime(run_day.year, run_day.month, run_day.day, 9, 30, tzinfo=TZ)
                      if run_day < today else datetime.now(TZ))
            data = OperationCreate(kind='buy', price=price, quantity=quantity, fee=D('0'),
                                   expected_version=current['version'],
                                   note=f"定投计划 #{plan['id']} 自动执行",
                                   executed_at=moment)
            trade(db, plan['project_id'], data, plan_id=plan['id'])
            executed += 1
            run_day = _advance(run_day, plan['period'])
        db.execute('UPDATE investment_plans SET next_run=? WHERE id=?', (run_day.isoformat(), plan['id']))
        db.execute('INSERT INTO notifications(project_id,kind,title,message,pnl,created_at) VALUES(?,?,?,?,?,?)',
                   (plan['project_id'], 'system', '定投已执行',
                    f"项目「{row['name']}」定投计划 #{plan['id']} 已按 {money(price)} 元价格买入 {money(amount)} 元，流水已追加到项目操作记录。",
                    None, now()))
    return executed


def delete_plan_operation(db, pid: str, operation_id: int):
    """删除定投生成的流水并逆向回退买入（模拟定投失败）。仅限定投记录。"""
    op = db.execute('SELECT * FROM operations WHERE id=? AND project_id=?', (operation_id, pid)).fetchone()
    if not op:
        raise HTTPException(404, '操作记录不存在')
    if op['plan_id'] is None:
        raise HTTPException(422, '仅定投生成的记录可以删除回退')
    row = project(db, pid)
    if row['status'] == 'closed':
        raise HTTPException(409, '项目已结项，定投记录不可再回退')
    price, qty, fee = D(op['price']), D(op['quantity']), D(op['fee'])
    p_qty, p_basis, p_invested = D(row['quantity']), D(row['cost_basis']), D(row['invested'])
    if qty > p_qty:
        raise HTTPException(409, '持仓已变动，无法回退该笔定投')
    cost = price * qty + fee
    db.execute('UPDATE projects SET quantity=?,cost_basis=?,invested=?,version=version+1 WHERE id=?',
               (str(p_qty - qty), str(p_basis - cost), str(p_invested - cost), pid))
    db.execute('DELETE FROM operations WHERE id=?', (operation_id,))
    db.execute('INSERT INTO notifications(project_id,kind,title,message,pnl,created_at) VALUES(?,?,?,?,?,?)',
               (pid, 'system', '定投记录已回退',
                f"项目「{row['name']}」一笔定投买入（{money(price)} 元 × {qty}）已删除并回退账务，可用于模拟定投失败。",
                None, now()))
    return {'deleted': operation_id}
