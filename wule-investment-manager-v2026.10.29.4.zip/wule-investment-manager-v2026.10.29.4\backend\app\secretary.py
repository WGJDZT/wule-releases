"""智能秘书：OpenAI 兼容协议接入（DeepSeek/通义/Kimi 等），带账本工具调用循环。

设计约束：
- API key 等配置仅存本地 SQLite settings 表，不出本机（除调用 LLM 服务本身）。
- 工具均为只读查询，不会修改任何账务数据。
- Decimal 结果一律先转字符串再序列化，保证金额精度不被二进制浮点破坏。
"""
import json
import httpx
from datetime import date as _date, datetime, timedelta
from decimal import Decimal
from .accounting import ledger, project, serialize, day_detail, daily_series, money, TZ
from .db import connect

DEFAULT_BASE_URL = 'https://api.deepseek.com'
DEFAULT_MODEL = 'deepseek-chat'
SETTING_KEYS = ('secretary_base_url', 'secretary_api_key', 'secretary_model')


def get_settings():
    with connect() as db:
        rows = db.execute(
            f"SELECT key,value FROM settings WHERE key IN ({','.join('?' * len(SETTING_KEYS))})",
            SETTING_KEYS).fetchall()
    cfg = {r['key']: r['value'] for r in rows}
    return {
        'base_url': cfg.get('secretary_base_url') or DEFAULT_BASE_URL,
        'model': cfg.get('secretary_model') or DEFAULT_MODEL,
        'has_key': bool(cfg.get('secretary_api_key')),
        'api_key_masked': ('*' * 8 + cfg['secretary_api_key'][-4:]) if cfg.get('secretary_api_key') else '',
    }


def save_settings(base_url: str, model: str, api_key: str | None):
    with connect() as db:
        for key, value in (('secretary_base_url', base_url.strip()),
                           ('secretary_model', model.strip())):
            if value:
                db.execute('INSERT INTO settings(key,value) VALUES(?,?) '
                           'ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key, value))
        # api_key 传 None 表示保持不变，传空串表示清除。
        if api_key is not None:
            db.execute('INSERT INTO settings(key,value) VALUES(?,?) '
                       'ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                       ('secretary_api_key', api_key.strip()))


# ---------- 工具（只读查询） ----------

def _ledger_overview(db):
    return ledger(db)


def _project_list(db):
    rows = db.execute('SELECT id FROM projects ORDER BY created_at DESC LIMIT 20').fetchall()
    return [serialize(project(db, r['id'])) for r in rows]


def _project_operations(db, pid: str):
    rows = db.execute('SELECT * FROM operations WHERE project_id=? ORDER BY created_at DESC,id DESC LIMIT 20',
                      (pid,)).fetchall()
    return [dict(r) for r in rows]


def _goals_progress(db):
    # 与 main.goal_progress 同口径：current = 对象当前累计盈亏 - 创建时基线。
    today = datetime.now(TZ).date()
    out = []
    for row in db.execute('SELECT * FROM goals ORDER BY created_at DESC LIMIT 20').fetchall():
        pnl = Decimal(serialize(project(db, row['project_id']))['total_pnl']) if row['project_id'] \
            else Decimal(ledger(db)['pnl'])
        current = pnl - Decimal(row['baseline_pnl'])
        remaining = (datetime.fromisoformat(row['ends_on']).date() - today).days
        out.append({**dict(row), 'current_pnl': money(current),
                    'completion_percent': str(current / Decimal(row['target']) * 100),
                    'remaining_days': max(0, remaining),
                    'achieved': current >= Decimal(row['target'])})
    return out


def _day_pnl(db, day: str):
    _date.fromisoformat(day)  # 校验格式 YYYY-MM-DD
    return day_detail(db, day)


def _daily_series(db, days: int):
    days = max(1, min(days, 90))
    rows = db.execute('SELECT day,pnl FROM ledger_snapshots ORDER BY day DESC LIMIT ?', (days + 1,)).fetchall()
    return [{'day': r['day'], 'pnl': r['pnl']} for r in reversed(rows)][1:]  # 首行是期初基准，剔除


TOOLS_SPEC = [
    {'type': 'function', 'function': {
        'name': 'ledger_overview', 'description': '查询当前总账：总资产、本金、累计盈亏、持仓市值、现金等汇总'}},
    {'type': 'function', 'function': {
        'name': 'project_list', 'description': '查询项目列表（最近20个）：每个项目的持仓、成本、现价、已实现/浮动盈亏、状态'}},
    {'type': 'function', 'function': {
        'name': 'project_operations', 'description': '查询某个项目的操作记录（开仓/加仓/减仓/结项流水，最近20条）',
        'parameters': {'type': 'object', 'properties': {
            'project_id': {'type': 'string', 'description': '项目编号，如 STK-20261026-001'}},
            'required': ['project_id']}}},
    {'type': 'function', 'function': {
        'name': 'goals_progress', 'description': '查询盈利目标列表及完成进度'}},
    {'type': 'function', 'function': {
        'name': 'day_pnl', 'description': '查询某一天的盈亏明细（当日盈亏、总资产、累计盈亏、当日操作流水）',
        'parameters': {'type': 'object', 'properties': {
            'day': {'type': 'string', 'description': '日期，格式 YYYY-MM-DD'}},
            'required': ['day']}}},
    {'type': 'function', 'function': {
        'name': 'daily_series', 'description': '查询最近若干天的每日盈亏序列（来自每日快照差分）',
        'parameters': {'type': 'object', 'properties': {
            'days': {'type': 'integer', 'description': '最近天数，1-90，默认 30'}},
            'required': []}}},
]

TOOL_FUNCS = {
    'ledger_overview': lambda db, a: _ledger_overview(db),
    'project_list': lambda db, a: _project_list(db),
    'project_operations': lambda db, a: _project_operations(db, a['project_id']),
    'goals_progress': lambda db, a: _goals_progress(db),
    'day_pnl': lambda db, a: _day_pnl(db, a['day']),
    'daily_series': lambda db, a: _daily_series(db, int(a.get('days', 30))),
}


def _run_tool(db, name: str, arguments: str):
    args = json.loads(arguments) if arguments.strip() else {}
    data = TOOL_FUNCS[name](db, args)
    return json.dumps(data, ensure_ascii=False, default=str)


SYSTEM_PROMPT = (
    '你是"我悟了投资管理有限公司"的智能秘书，服务老板管理其个人投资账本。'
    '你可以调用工具查询实时账务数据（总账、项目、操作记录、目标、每日盈亏）。'
    '回答规则：1)始终用中文，称呼"老板"；2)涉及金额引用工具返回的精确数值，不要心算改写；'
    '3)需要数据时先调工具，不要编造；4)给出简明、结构化的分析，必要时用列表；'
    '5)你是决策辅助而非投资建议发布者，涉及买卖决策时提示风险；6)今日日期会随系统时间变化，以工具返回为准。'
)


def chat(messages: list[dict]):
    """执行一轮完整对话：LLM ↔ 工具循环，返回 (回复文本, 步骤轨迹)。"""
    cfg = get_settings()
    if not cfg['has_key']:
        raise PermissionError('尚未设置秘书的 API Key，请先在右上角"设置"中配置')
    base = cfg['base_url'].rstrip('/')
    convo = [{'role': 'system', 'content': SYSTEM_PROMPT}, *messages][-30:]
    steps: list[dict] = []
    headers = {'Authorization': f"Bearer {read_key()}"}
    with connect() as db:
        for _ in range(6):
            r = httpx.post(f'{base}/chat/completions', headers=headers, timeout=120, json={
                'model': cfg['model'], 'messages': convo, 'tools': TOOLS_SPEC})
            if r.status_code != 200:
                raise RuntimeError(f'模型服务返回 {r.status_code}：{r.text[:200]}')
            msg = r.json()['choices'][0]['message']
            tool_calls = msg.get('tool_calls')
            if not tool_calls:
                return msg.get('content') or '', steps
            convo.append({'role': 'assistant', 'content': msg.get('content') or '',
                          'tool_calls': tool_calls})
            for call in tool_calls:
                fn, args_raw = call['function']['name'], call['function'].get('arguments') or ''
                try:
                    result = _run_tool(db, fn, args_raw)
                    brief = 'ok'
                except Exception as e:  # 工具失败也回传给模型，让其调整
                    result, brief = json.dumps({'error': str(e)}, ensure_ascii=False), f'error: {e}'
                steps.append({'tool': fn, 'arguments': args_raw, 'brief': brief})
                convo.append({'role': 'tool', 'tool_call_id': call['id'],
                              'content': result[:6000]})
    raise RuntimeError('工具调用轮数已达上限，请缩小问题范围后重试')


def read_key() -> str:
    with connect() as db:
        row = db.execute("SELECT value FROM settings WHERE key='secretary_api_key'").fetchone()
    return row['value'] if row else ''
