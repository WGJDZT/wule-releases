"""历史项目快照自动回填（升级自动迁移能力，启动后台执行）。

背景：日度盈亏构成分解（流向图）依赖 project_daily_snapshots 每日项目快照，
v2026.11.1.1 启用该表后历史日期没有快照数据，老用户升级后历史明细无流向图。
本模块在服务启动时后台自动回填缺失日期，使新功能对存量数据完整可用：
1. 旧版本写入的行 price_day 为空 → 按 quote_at/created_at 归属（一次性修复，幂等）；
2. 总账快照日（今天之前）中缺失 (day, project_id) 行的 → 按流水重放补齐：
   与 trade() 增量语义一致（open/buy 加 basis/invested/qty；sell/close 移除成本；
   平账 close 流水 qty=0、price=0 按 invested=-realized_pnl、realized=realized_pnl 记账，
   count_assets=True 则 proceeds=realized_pnl）；
3. 历史价格：股票/场内用日 K 收盘（东方财富，腾讯兜底），场外基金用天天基金历史净值
   （DWJZ），取不到回退当日最后成交价；price_day=快照日（回填价即该日收盘/净值）；
4. INSERT OR IGNORE 幂等，不覆盖已有实时行；已删除项目的流水已级联清除，无法追溯
   （已知边界，其贡献缺失使历史日合计与总账差分存在差额，与当日删除的口径处理一致）。

设计约束：行情拉取不持有写事务（先读+计划、再短事务写入），避免阻塞交易；
每次启动至多执行一次，回填完成后再次启动为快速空转（仅一次重放扫描，无行情请求）。
"""
import re
from collections import defaultdict
from decimal import Decimal
from datetime import datetime

import httpx

from .accounting import TZ
from .db import connect
from .watch import kline

D = Decimal
ZERO = D('0')


def _hist_prices(code: str, category: str) -> dict:
    """按代码拉取历史价格表 {日期: 价格}：股票日K收盘 / 场外基金净值。"""
    out = {}
    code = (code or '').strip()
    is_nav = category == 'fund' and re.fullmatch(r'\d{6}', code) and not code.startswith(('15', '16', '50', '51', '56', '58'))
    try:
        if is_nav:
            r = httpx.get('https://api.fund.eastmoney.com/f10/lsjz',
                          params={'fundCode': code, 'pageIndex': 1, 'pageSize': 100},
                          headers={'Referer': 'https://fund.eastmoney.com/',
                                   'User-Agent': 'Mozilla/5.0'}, timeout=10)
            for it in ((r.json().get('Data') or {}).get('LSJZList') or []):
                try:
                    if it.get('FSRQ') and it.get('DWJZ') and D(it['DWJZ']) > 0:
                        out[it['FSRQ']] = D(it['DWJZ'])
                except Exception:
                    continue
        elif re.fullmatch(r'\d{6}', code):
            for bar in kline(code, 500):
                out[bar['date']] = D(str(bar['close']))
    except Exception:
        pass  # 单代码行情失败不影响其余回填，缺失日回退最后成交价
    return out


def _price_at(hist: dict, day: str, fallback: Decimal) -> Decimal:
    if day in hist:
        return hist[day]
    earlier = [d for d in hist if d <= day]
    return hist[max(earlier)] if earlier else fallback


def _replay(ops_by_pid: dict, cut: str, settle_assets: set):
    """重放 created_at<=cut 的流水 → {pid: (qty, invested, proceeds, realized, has_op)}。"""
    st = {}
    for pid, ops in ops_by_pid.items():
        qty = basis = invested = proceeds = realized = ZERO
        has_op = False
        for o in ops:
            if o['created_at'] > cut:
                break
            has_op = True
            price, quantity, fee = D(o['price']), D(o['quantity']), D(o['fee'])
            rp = D(o['realized_pnl'])
            if o['kind'] == 'close' and quantity == 0 and price == 0:
                # 平账创建：本金冲减/回补，realized 记盈亏额
                if pid in settle_assets:
                    proceeds += rp
                else:
                    invested -= rp
                realized += rp
            elif o['kind'] in ('open', 'buy'):
                cost = price * quantity + fee
                basis += cost
                invested += cost
                qty += quantity
            else:
                quantity = min(quantity, qty)  # 防御历史脏数据
                removed = basis if quantity == qty else basis * quantity / qty
                net = price * quantity - fee
                realized += net - removed
                proceeds += net
                basis -= removed
                qty -= quantity
        st[pid] = (qty, invested, proceeds, realized, has_op)
    return st


def run() -> int:
    """执行自动回填（幂等）。返回新写入行数；无需回填时为 0。行情拉取不持有写事务。"""
    today = datetime.now(TZ).date().isoformat()
    # 1) 一次性修复旧版本行的 price_day（幂等）：NULL → quote_at/created_at 的日期
    with connect(True) as db:
        db.execute('''UPDATE project_daily_snapshots SET price_day=(
            SELECT COALESCE(substr(p.quote_at,1,10), substr(p.created_at,1,10))
            FROM projects p WHERE p.id=project_id)
            WHERE price_day IS NULL AND day<?''', (today,))
    # 2) 读取基础数据（读事务）
    with connect() as db:
        days = [r['day'] for r in db.execute(
            'SELECT DISTINCT day FROM ledger_snapshots WHERE day<? ORDER BY day', (today,))]
        if not days:
            return 0
        projects = {r['id']: dict(r) for r in db.execute('SELECT id,category,code FROM projects')}
        ops_by_pid = defaultdict(list)
        for r in db.execute('SELECT project_id,kind,price,quantity,fee,realized_pnl,created_at '
                            'FROM operations ORDER BY created_at,id'):
            ops_by_pid[r['project_id']].append(dict(r))
        settle_assets = {r['id'] for r in db.execute(
            "SELECT id FROM projects WHERE category='settle' AND proceeds!=0")}
        existing = {(r['day'], r['project_id']) for r in db.execute(
            'SELECT day,project_id FROM project_daily_snapshots')}
    # 3) 逐日重放并计算缺失行（行情拉取在此阶段，不持有事务）
    plan = []
    price_cache = {}
    for day in days:
        cut = day + 'T23:59:59.999999'
        st = _replay(ops_by_pid, cut, settle_assets)
        for pid, (q, i, p, rl, has_op) in st.items():
            if not has_op or (day, pid) in existing:
                continue
            proj = projects.get(pid)
            if not proj:
                continue  # 已删除项目流水不可追溯（级联清除）
            cat, code = proj['category'], (proj['code'] or '').strip()
            if cat == 'settle':
                price_v = ZERO
            else:
                key = f'{cat}:{code}'
                if key not in price_cache:
                    price_cache[key] = _hist_prices(code, cat)
                fallback = ZERO
                for o in reversed(ops_by_pid[pid]):
                    if o['created_at'] <= cut and D(o['price']) > 0:
                        fallback = D(o['price'])
                        break
                price_v = _price_at(price_cache[key], day, fallback)
            plan.append((day, pid, str(q), str(price_v), str(i), str(p), str(rl), day, ))
    if not plan:
        return 0
    # 4) 短事务写入（INSERT OR IGNORE 幂等）
    filled = 0
    with connect(True) as db:
        for day, pid, q, price_v, i, p, rl, pd in plan:
            cur = db.execute(
                '''INSERT OR IGNORE INTO project_daily_snapshots
                   (day,project_id,quantity,price,invested,proceeds,realized,created_at,price_day)
                   VALUES(?,?,?,?,?,?,?,?,?)''',
                (day, pid, q, price_v, i, p, rl, day + 'T23:59:59+08:00', pd))
            filled += cur.rowcount if cur.rowcount > 0 else 0
    return filled
