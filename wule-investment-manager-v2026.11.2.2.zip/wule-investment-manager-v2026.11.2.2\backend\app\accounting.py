from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from fastapi import HTTPException
from .models import ProjectCreate, OperationCreate

TZ = timezone(timedelta(hours=8))
D = Decimal
ZERO = D('0')


def now():
    return datetime.now(TZ).isoformat(timespec='microseconds')


def money(value):
    return str(D(value).quantize(D('.01'), rounding=ROUND_HALF_UP))


def project(db, project_id):
    row = db.execute('SELECT * FROM projects WHERE id=?', (project_id,)).fetchone()
    if not row:
        raise HTTPException(404, '项目不存在')
    return row


def serialize(row):
    item = dict(row)
    qty, basis, price = map(D, (item['quantity'], item['cost_basis'], item['current_price']))
    item.update(cost_price=str(basis / qty) if qty else '0', market_value=money(qty * price),
                unrealized_pnl=money(qty * price - basis),
                total_pnl=money(qty * price - basis + D(item['realized_pnl'])))
    if item['category'] == 'settle':
        # 平账项目：proceeds 非零表示创建时勾选了“计入总资产”。
        item['count_assets'] = D(item['proceeds']) != 0
        item['skip_daily'] = bool(item['skip_daily'])
    return item


def create_project(db, data: ProjectCreate):
    cat = db.execute('SELECT prefix FROM categories WHERE id=?', (data.category,)).fetchone()
    if not cat:
        raise HTTPException(422, '资产类别不存在')
    stamp = now()
    prefix = f"{cat['prefix']}-{datetime.now(TZ):%Y%m%d}-"
    # Caller holds BEGIN IMMEDIATE; sequence allocation and insert share the lock.
    last = db.execute('SELECT id FROM projects WHERE id LIKE ? ORDER BY LENGTH(id) DESC,id DESC LIMIT 1', (prefix+'%',)).fetchone()
    seq = int(last['id'].rsplit('-', 1)[1]) + 1 if last else 1
    pid = f'{prefix}{seq:03d}'
    started = (data.started_on or date.fromisoformat(stamp[:10])).isoformat()
    if data.category == 'settle':
        # 平账项目：不绑定标的、只有盈亏金额、默认结项。
        # 默认口径（count_assets=False）：盈亏冲减/回补累计本金（invested=-amount），
        # 总资产不变，总盈亏=资产-本金 自然变化 amount。
        # 勾选用计入总资产（count_assets=True）：回款记为盈亏额（proceeds=amount），本金不变。
        amount = data.settle_pnl
        invested, proceeds = (D('0'), amount) if data.count_assets else (-amount, D('0'))
        db.execute('''INSERT INTO projects(id,name,category,code,instrument_name,quantity,cost_basis,
            current_price,invested,proceeds,realized_pnl,status,started_on,ended_on,created_at,closed_at,skip_daily)
            VALUES(?,?,?,'-','平账','0','0','0',?,?,?,'closed',?,?,?,?,?)''',
            (pid,data.name,data.category,str(invested),str(proceeds),str(amount),started,started,stamp,stamp,1 if data.skip_daily else 0))
        db.execute('''INSERT INTO operations(project_id,kind,price,quantity,fee,realized_pnl,note,created_at)
            VALUES(?,'close','0','0','0',?,?,?)''', (pid,str(amount),data.note,stamp))
        return serialize(project(db, pid))
    basis = data.price * data.quantity + data.fee
    db.execute('''INSERT INTO projects(id,name,category,code,instrument_name,quantity,cost_basis,
        current_price,invested,started_on,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
        (pid,data.name,data.category,data.code,data.instrument_name,str(data.quantity),str(basis),str(data.current_price or data.price),str(basis),started,stamp))
    db.execute('''INSERT INTO operations(project_id,kind,price,quantity,fee,realized_pnl,note,created_at)
        VALUES(?,?,?,?,?,?,?,?)''', (pid,'open',str(data.price),str(data.quantity),str(data.fee),'0',data.note,stamp))
    return serialize(project(db, pid))


def trade(db, pid: str, data: OperationCreate, plan_id: int | None = None):
    row = project(db, pid)
    if row['status'] == 'closed':
        raise HTTPException(409, '已结项项目禁止继续操作')
    if row['version'] != data.expected_version:
        raise HTTPException(409, '项目已更新，请刷新后重试')
    qty, basis, realized, invested, proceeds = map(D, (row['quantity'],row['cost_basis'],row['realized_pnl'],row['invested'],row['proceeds']))
    delta = ZERO
    if data.kind == 'buy':
        basis += data.price * data.quantity + data.fee
        invested += data.price * data.quantity + data.fee
        qty += data.quantity
    else:
        if data.quantity > qty or (data.kind == 'close' and data.quantity != qty):
            raise HTTPException(422, '卖出数量超出持仓，或结项未卖出全部持仓')
        removed = basis if data.quantity == qty else basis * data.quantity / qty
        net = data.price * data.quantity - data.fee
        delta = net - removed
        realized += delta
        proceeds += net
        basis -= removed
        qty -= data.quantity
    closed = qty == 0
    stamp = now()
    ended = None
    if closed:
        ended = (data.ended_on or date.fromisoformat(stamp[:10])).isoformat()
        started = row['started_on']
        if started and ended < started:
            raise HTTPException(422, '结束日期不能早于开始日期')
    db.execute('''UPDATE projects SET quantity=?,cost_basis=?,realized_pnl=?,invested=?,proceeds=?,
        current_price=?,status=?,closed_at=?,ended_on=?,version=version+1 WHERE id=?''',
        (str(qty),str(basis),str(realized),str(invested),str(proceeds),str(data.price),
         'closed' if closed else 'active',stamp if closed else None,ended,pid))
    # 操作记录时间：补录历史时用指定的成交时间，否则取当前；账务快照仍以落账时刻为准。
    operated_at = data.executed_at.isoformat() if data.executed_at else stamp
    db.execute('''INSERT INTO operations(project_id,kind,price,quantity,fee,realized_pnl,note,created_at,plan_id)
        VALUES(?,?,?,?,?,?,?,?,?)''', (pid,data.kind,str(data.price),str(data.quantity),str(data.fee),str(delta),data.note,operated_at,plan_id))
    return serialize(project(db,pid))


def ledger(db, category=None):
    rows = db.execute('SELECT * FROM projects' + (' WHERE category=?' if category else ''), (category,) if category else ()).fetchall()
    principal = assets = realized = floating = ZERO
    distribution = {}
    pnl_by_category = {}
    for row in rows:
        qty,basis,price = map(D,(row['quantity'],row['cost_basis'],row['current_price']))
        value = qty * price
        principal += D(row['invested'])
        assets += value + D(row['proceeds'])
        realized += D(row['realized_pnl'])
        floating += value - basis
        distribution[row['category']] = distribution.get(row['category'],ZERO) + value
        pnl_by_category[row['category']] = pnl_by_category.get(row['category'],ZERO) + (value - basis + D(row['realized_pnl']))
    adjustment = sum((D(r[0]) for r in db.execute('SELECT amount FROM ledger_adjustments')),ZERO) if not category else ZERO
    assets += adjustment
    today = datetime.now(TZ).date().isoformat()
    previous = db.execute('SELECT day,pnl FROM ledger_snapshots WHERE category=? AND day<? ORDER BY day DESC LIMIT 1', (category or 'all',today)).fetchone()
    pnl = assets-principal
    # 今日盈亏只来自非平账项目的行情/交易变动。平账项目默认排除（skip_daily=1），
    # 可在项目详情用「计入当日盈亏」开关按项目加入，兼容旧版本数据的手动同步。
    # 仅在总账视图（category=None）扣除；大类快照本身不含平账项目，无需再扣。
    # 删除项目跳变无需再扣：贡献按现存项目状态差分计算，已删除项目天然不在其中。
    skip_today = ZERO
    if not category:
        for r in db.execute("SELECT realized_pnl FROM projects WHERE category='settle' AND skip_daily=1 AND created_at LIKE ?", (today+'%',)):
            skip_today += D(r['realized_pnl'])
    # 今日盈亏按「价格所属行情日」归属（与日度明细构成分解同源）：基金净值/收盘价滞后发布时
    # （如周五收盘后快照仍是周四净值、次日才刷到周五净值），价差归属真正的交易日，
    # 非交易日不再出现伪流水；交易贡献按「上一快照日 → 现值」的状态差分归属今日。
    daily = None
    if previous:
        prev_day = previous['day']
        _, _, by_pid = snapshot_timeline(db)
        total = ZERO
        for row in rows:
            if category and row['category'] != category:
                continue
            pid_rows = by_pid.get(row['id'], [])
            pd_live = (row['quote_at'] or row['created_at'] or '')[:10] or None
            p2 = price_at_day(pid_rows, today, live=(D(row['current_price']), pd_live) if pd_live else None)
            prv = None
            for r in pid_rows:
                if r['day'] <= prev_day and (prv is None or r['day'] > prv['day']):
                    prv = r
            q_l, inv_l, pr_l = D(row['quantity']), D(row['invested']), D(row['proceeds'])
            if prv is None or p2 is None:
                # 期初无快照（今日新建）：贡献 = 期末资产 − 本金（不拆行情/交易）
                total += q_l * (p2 or ZERO) + pr_l - inv_l
            else:
                p1 = price_at_day(pid_rows, prev_day) or prv['price']
                total += (q_l * p2 + pr_l - inv_l) - (prv['qty'] * p1 + prv['pr'] - prv['inv'])
        daily = money(total-skip_today)
    return dict(principal=money(principal),assets=money(assets),pnl=money(pnl),
                today_pnl=daily,realized_pnl=money(realized),unrealized_pnl=money(floating),
                adjustments=money(adjustment),distribution=[dict(name=k,value=money(v)) for k,v in distribution.items()],
                pnl_distribution=[dict(name=k,value=money(v)) for k,v in pnl_by_category.items()],
                project_count=len(rows),active_count=sum(r['status']=='active' for r in rows))


def snapshot(db):
    stamp=now()
    for cat in [None]+[r['id'] for r in db.execute('SELECT id FROM categories')]:
        totals=ledger(db,cat)
        db.execute('''INSERT INTO ledger_snapshots(day,category,principal,assets,pnl,created_at) VALUES(?,?,?,?,?,?)
            ON CONFLICT(day,category) DO UPDATE SET principal=excluded.principal,assets=excluded.assets,
            pnl=excluded.pnl,created_at=excluded.created_at''',
            (stamp[:10],cat or 'all',totals['principal'],totals['assets'],totals['pnl'],stamp))
    # 项目级每日期末快照（UPSERT 覆盖当天）：日度盈亏构成分解（行情/交易拆分）的数据基础。
    # price_day 记录快照价格所属的行情日（基金净值/股票行情的 market_at 日期，未刷新过的
    # 项目回退建仓日）：净值/收盘价滞后发布时，日度盈亏按 price_day 归属真正的交易日。
    for r in db.execute('SELECT id,quantity,current_price,invested,proceeds,realized_pnl,quote_at,created_at FROM projects'):
        pd=(r['quote_at'] or r['created_at'] or '')[:10] or None
        db.execute('''INSERT INTO project_daily_snapshots(day,project_id,quantity,price,invested,proceeds,realized,created_at,price_day)
            VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(day,project_id) DO UPDATE SET quantity=excluded.quantity,
            price=excluded.price,invested=excluded.invested,proceeds=excluded.proceeds,
            realized=excluded.realized,created_at=excluded.created_at,price_day=excluded.price_day''',
            (stamp[:10],r['id'],r['quantity'],r['current_price'],r['invested'],r['proceeds'],r['realized_pnl'],stamp,pd))


def snapshot_timeline(db):
    """项目快照时间线：日度盈亏「价格日归属制」的数据底座。

    返回 (meta, by_day, by_pid)：
    - meta: {pid: {name,category,status,skip_daily}}（仅现存项目；已删除项目不在其中）；
    - by_day: {day: {pid: 行}} 精确日查询；by_pid: {pid: [行]} 按 day 升序，供行情日定价查询；
    - 行: dict(pid, day, qty, price, pd, inv, pr)；pd=price_day（价格所属行情日），
      NULL（旧数据/回填行，其价格本就按快照日取值）回退快照日，保持旧口径。
    """
    meta={r['id']:dict(name=r['name'],category=r['category'],status=r['status'],
                       skip_daily=bool(r['skip_daily']))
          for r in db.execute('SELECT id,name,category,status,skip_daily FROM projects')}
    by_day,by_pid={},{}
    for r in db.execute('SELECT day,project_id,quantity,price,price_day,invested,proceeds '
                        'FROM project_daily_snapshots ORDER BY day,project_id'):
        row=dict(pid=r['project_id'],day=r['day'],qty=D(r['quantity']),price=D(r['price']),
                 pd=r['price_day'] or r['day'],inv=D(r['invested']),pr=D(r['proceeds']))
        by_day.setdefault(r['day'],{})[r['project_id']]=row
        by_pid.setdefault(r['project_id'],[]).append(row)
    return meta,by_day,by_pid


def price_at_day(pid_rows, day, live=None):
    """项目在市场日 day 的定价：取 price_day<=day 中最大 price_day 行的价格（同行情日取最新快照）。

    快照行 price_day 滞后（如周六快照仍是周五净值）时，后续快照行会带回该行情日的价格，
    使历史交易日的定价随行情发布自动补全。live=(价格, 行情日) 为实时候选（今日口径用），
    与快照同行情日时优先取实时值。无任何候选返回 None。
    """
    best=None
    for r in pid_rows:
        if r['pd']<=day and (best is None or (r['pd'],r['day'])>(best['pd'],best['day'])):
            best=r
    if live and live[1] and live[1]<=day and (best is None or live[1]>=best['pd']):
        return live[0]
    return best['price'] if best else None


def day_contribs(tl, day, prev_day, category='all'):
    """day 相对 prev_day 的各项目贡献分解（两端均按「价格所属行情日」定价）。

    贡献 = (期末市值+回款) − (期初市值+回款) − (本金变化)；
    行情 = 期初份额 × (P(day) − P(prev_day))——净值/收盘价滞后发布时自动归属真正交易日；
    交易 = 贡献 − 行情。返回 (items, contrib_total, move_total, daily_total)：
    - items 含每个现存项目的明细（settled_excluded 标注 skip_daily=1 平账），
      已删除项目不返回（跳变由 pnl_exclusions 口径排除，day_detail 自行构造 deleted 行）；
    - contrib_total/move_total 为排除 skip_daily=1 平账后的展示合计；
    - daily_total 为全部非删除项目贡献合计（日度 daily 口径，再减平账扣除/删除排除）。
    """
    meta,by_day,by_pid=tl
    cur_map,prev_map=by_day.get(day,{}),by_day.get(prev_day,{})
    items,contrib_total,move_total,daily_total=[],ZERO,ZERO,ZERO
    for pid in sorted(set(cur_map)|set(prev_map)):
        m=meta.get(pid)
        if m is None:
            continue  # 已删除项目：不计入（删除跳变已由 pnl_exclusions 排除）
        if category!='all' and m['category']!=category:
            continue
        cur,prv=cur_map.get(pid),prev_map.get(pid)
        skip=bool(m['skip_daily']) if m['category']=='settle' else False
        pid_rows=by_pid.get(pid,[])
        if prv is None:
            # 新项目（期初无快照，开仓当天）：行情/交易不拆分，按行情日定价给当日贡献
            p2=price_at_day(pid_rows,day)
            contrib=((cur['qty']*p2+cur['pr'])-cur['inv']) if (cur and p2 is not None) else ZERO
            if not skip:
                contrib_total+=contrib
            daily_total+=contrib
            items.append(dict(name=m['name'],code=pid,category=m['category'],status=m['status'],
                              deleted=False,new=True,move=None,trade=None,contrib=money(contrib),
                              settled_excluded=skip))
            continue
        if cur is None:
            continue  # 期初有、期末无（跨日删除残留）：不计入
        p1=price_at_day(pid_rows,prev_day) or prv['price']
        p2=price_at_day(pid_rows,day) or cur['price']
        contrib=(cur['qty']*p2+cur['pr'])-(prv['qty']*p1+prv['pr'])-(cur['inv']-prv['inv'])
        move=prv['qty']*(p2-p1)
        trade=contrib-move
        if not skip:
            contrib_total+=contrib
            move_total+=move
        daily_total+=contrib
        items.append(dict(name=m['name'],code=pid,category=m['category'],status=m['status'],
                          deleted=False,new=False,move=money(move),trade=money(trade),
                          contrib=money(contrib),settled_excluded=skip))
    items.sort(key=lambda x:-abs(Decimal(x['contrib'])))
    return items,contrib_total,move_total,daily_total


def daily_series(db, start, end, category='all'):
    # 逐日盈亏改为「价格日归属制」，与当日明细构成分解同源：行情贡献按快照价格所属
    # 行情日（price_day）归属，基金净值/收盘价滞后发布时非交易日不再出现伪流水；
    # 交易贡献按落账快照日归属。pnl/assets 仍为快照即时值。差分基准取范围前最近快照日。
    tl=snapshot_timeline(db)
    base=db.execute("SELECT day FROM ledger_snapshots WHERE category=? AND day<? ORDER BY day DESC LIMIT 1",(category,start)).fetchone()
    prev=base['day'] if base else None
    items=[]
    for r in db.execute("SELECT day,pnl,assets FROM ledger_snapshots WHERE category=? AND day>=? AND day<=? ORDER BY day",(category,start,end)):
        daily=None
        if prev is not None:
            _,_,_,daily_total=day_contribs(tl,r['day'],prev,category)
            if category=='all':
                # 日度盈亏排除当天创建的平账项目（skip_daily=1），与今日盈亏口径一致。
                # 删除跳变无需扣除：贡献按现存项目快照状态计算，已删除项目天然不在其中。
                settle=sum((D(x[0]) for x in db.execute("SELECT realized_pnl FROM projects WHERE category='settle' AND skip_daily=1 AND created_at LIKE ?", (r['day']+'%',))), ZERO)
                daily_total-=settle
            daily=money(daily_total)
        items.append(dict(day=r['day'], pnl=money(D(r['pnl'])),
                          daily=daily, assets=r['assets']))
        prev=r['day']
    return items


def day_detail(db, day, category='all'):
    totals = db.execute("SELECT principal,assets,pnl FROM ledger_snapshots WHERE category=? AND day=?", (category,day)).fetchone()
    rows = db.execute('''SELECT o.id,o.kind,o.price,o.quantity,o.fee,o.realized_pnl,o.note,o.created_at,
        p.name AS project_name,p.code,p.instrument_name,p.category
        FROM operations o JOIN projects p ON p.id=o.project_id
        WHERE o.created_at LIKE ? ORDER BY o.created_at DESC,o.id DESC LIMIT 100''', (day+'%',)).fetchall()
    summary = None
    if totals:
        # 仅总账视图扣除当天平账（skip_daily=1）；大类快照本身不含平账项目。
        # 删除跳变无需扣除：贡献按现存项目快照状态计算，已删除项目天然不在其中。
        settle = ZERO
        if category == 'all':
            settle = sum((D(x[0]) for x in db.execute("SELECT realized_pnl FROM projects WHERE category='settle' AND skip_daily=1 AND created_at LIKE ?", (day+'%',))), ZERO)
        summary = dict(day=day, principal=totals['principal'], assets=totals['assets'], pnl=totals['pnl'])
    # 当日盈亏构成：基于项目级每日快照（day 与前一快照日对比），当日与历史日期统一可查。
    # 每项目贡献 = (期末市值+回款) − (期初市值+回款) − (本金变化)，两端均按「价格所属行情日」
    # 定价：净值/收盘价滞后发布时（快照价属于更早行情日），后续快照会带回该行情日价格，
    # 价差自动归属真正的交易日，非交易日贡献为 0（与 daily_series、today_pnl 同源同口径）；
    # 行情部分 = 期初份额 × (P(day) − P(prev_day))，交易部分 = 贡献 − 行情。
    # 平账（skip_daily=1）与当天删除的跳变在当日盈亏公式中已排除，构成表中相应标注且不计入合计。
    prev_day_row = db.execute("SELECT day FROM ledger_snapshots WHERE category='all' AND day<? ORDER BY day DESC LIMIT 1", (day,)).fetchone()
    composition = None
    if prev_day_row:
        prev_day = prev_day_row['day']
        meta, by_day, by_pid = snapshot_timeline(db)
        items, contrib_total, move_total, daily_total = day_contribs((meta, by_day, by_pid), day, prev_day, category)
        cur_map, prev_map = by_day.get(day, {}), by_day.get(prev_day, {})
        for pid in sorted(set(cur_map) | set(prev_map)):
            if pid in meta:
                continue  # 现存项目已由 day_contribs 处理
            # 已删除项目（当天删除残留快照 / 跨日删除无快照）：按 ID 前缀推断类别，
            # 用可用快照构造 deleted 行，展示被移除的累计盈亏（=−该时点 total_pnl）；
            # 删除跳变已由 pnl_exclusions 排除，此行不计入合计。
            cat = {'stk': 'stock', 'fund': 'fund', 'settle': 'settle',
                   'oth': 'other'}.get(pid.split('-')[0].lower(), 'other')
            if category != 'all' and cat != category:
                continue
            src = prev_map.get(pid) or cur_map.get(pid)
            contrib = src['inv'] - src['qty'] * src['price'] - src['pr']
            items.append(dict(name=pid, code=pid, category=cat,
                              status='closed', deleted=True, new=False, move=None,
                              trade=None, contrib=money(contrib)))
        items.sort(key=lambda x: -abs(Decimal(x['contrib'])))
        composition = dict(prev_day=prev_day, items=items,
                           move_total=money(move_total), contrib_total=money(contrib_total))
        if summary:
            # daily 与构成分解同源（价格日归属制）：全部非删除项目贡献合计，再减平账扣除/删除排除；
            # 无前基准（composition=None）时 daily 保持 None，不伪造数据。
            summary['daily'] = money(daily_total - settle) if category == 'all' else money(daily_total)
    return dict(day=day, totals=summary, operations=[dict(r) for r in rows], composition=composition)


def record_exclusion(db, amount, reason):
    """记录当日盈亏排除项（amount 为删除等操作造成的 pnl 跳变值）。"""
    stamp = now()
    db.execute('INSERT INTO pnl_exclusions(day,amount,reason,created_at) VALUES(?,?,?,?)',
               (stamp[:10], money(amount), reason, stamp))


def apply_operation_edit(db, pid: str, op_id: int, patch: dict):
    """修改一笔操作并全量重放项目账务。

    trade() 是增量记账，改历史一笔（如手续费）会影响其后所有增量，因此按时间顺序
    重放全部操作重算 quantity/cost_basis/realized_pnl/invested/proceeds 与每笔
    realized_pnl；重放中出现持仓为负或结项未清仓即 422（事务回滚，数据不变）。
    patch 仅提供 price/quantity/fee/note 中要修改的字段。平账项目不适用。
    """
    op = db.execute('SELECT * FROM operations WHERE id=? AND project_id=?', (op_id, pid)).fetchone()
    if not op:
        raise HTTPException(404, '操作记录不存在')
    ops = db.execute('SELECT * FROM operations WHERE project_id=? ORDER BY created_at,id', (pid,)).fetchall()
    row = project(db, pid)
    old_ended, old_closed_at = row['ended_on'], row['closed_at']
    qty = basis = realized = invested = proceeds = ZERO
    pnls, closed = {}, False
    for o in ops:
        p, q, f = D(o['price']), D(o['quantity']), D(o['fee'])
        if o['id'] == op_id:
            p = D(patch['price']) if patch.get('price') is not None else p
            q = D(patch['quantity']) if patch.get('quantity') is not None else q
            f = D(patch['fee']) if patch.get('fee') is not None else f
        if o['kind'] in ('open', 'buy'):
            cost = p * q + f
            basis += cost
            invested += cost
            qty += q
            pnls[o['id']] = '0'
        else:
            if q > qty:
                raise HTTPException(422, '修改后该笔卖出数量超过当时持仓，账务不成立')
            if o['kind'] == 'close' and q != qty:
                raise HTTPException(422, '修改后结项操作未卖出全部持仓，账务不成立')
            removed = basis if q == qty else basis * q / qty
            net = p * q - f
            delta = net - removed
            realized += delta
            proceeds += net
            basis -= removed
            qty -= q
            pnls[o['id']] = money(delta)
        # 每步随持仓重算结项状态：兼容「清仓→复项目→再买回」的操作历史。
        closed = qty == 0
    for oid, pnl in pnls.items():
        db.execute('UPDATE operations SET realized_pnl=? WHERE id=?', (pnl, oid))
    fields, args = [], []
    for key in ('price', 'quantity', 'fee'):
        if patch.get(key) is not None:
            fields.append(key + '=?')
            args.append(str(D(patch[key])))
    if patch.get('note') is not None:
        fields.append('note=?')
        args.append(patch['note'])
    if fields:
        db.execute(f"UPDATE operations SET {','.join(fields)} WHERE id=?", (*args, op_id))
    # 结项时间语义：重放后仍结项则保持原起止记录；未清仓则恢复进行中。
    db.execute('''UPDATE projects SET quantity=?,cost_basis=?,realized_pnl=?,invested=?,proceeds=?,
        status=?,closed_at=?,ended_on=?,version=version+1 WHERE id=?''',
               (str(qty), str(basis), str(realized), str(invested), str(proceeds),
                'closed' if closed else 'active',
                old_closed_at if closed else None, old_ended if closed else None, pid))
    return serialize(project(db, pid))


def reopen_project(db, pid: str):
    """复项目：已结项（非平账）项目恢复进行中，可继续买入（全仓做T卖出自动结项后买回同一项目）。

    仅改状态，不动 quantity/basis 等账务（清仓后本就归零），无流水记录。
    """
    row = project(db, pid)
    if row['category'] == 'settle':
        raise HTTPException(422, '平账项目无需复项目')
    if row['status'] != 'closed':
        raise HTTPException(422, '进行中项目无需复项目')
    db.execute("UPDATE projects SET status='active',closed_at=NULL,ended_on=NULL,version=version+1 WHERE id=?", (pid,))
    return serialize(project(db, pid))


def trade_metrics(db, row):
    """项目详情交易指标（Decimal 核算，仅展示用途）：

    - pnl_percent：累计盈亏 ÷ 累计买入本金 × 100。
    - last_trade / prev_trade：现价较最近一笔 / 第二笔成交价的涨跌百分比（做T参考）。
    成交价为 0 的流水（导入/历史脏数据）在查询层过滤，不挤占指标位；
    平账项目、无有效成交或买入本金为 0 时返回 None，前端显示占位符。
    """
    if row['category'] == 'settle':
        return dict(pnl_percent=None, last_trade=None, prev_trade=None)
    price_now, invested = D(row['current_price']), D(row['invested'])
    total_pnl = D(row['quantity'])*price_now - D(row['cost_basis']) + D(row['realized_pnl'])
    pnl_percent = money(total_pnl/invested*100) if invested else None

    def metric(op):
        p = D(op['price'])
        return dict(price=str(p.quantize(D('.000001'), rounding=ROUND_HALF_UP)),
                    percent=money((price_now-p)/p*100), at=op['created_at'])

    ops = db.execute('SELECT price,created_at FROM operations WHERE project_id=? AND price>0 ORDER BY created_at DESC,id DESC LIMIT 2', (row['id'],)).fetchall()
    return dict(pnl_percent=pnl_percent,
                last_trade=metric(ops[0]) if ops else None,
                prev_trade=metric(ops[1]) if len(ops) > 1 else None)
