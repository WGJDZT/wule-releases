import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = Path(os.environ.get('WULE_DATA_DIR', ROOT / 'data'))


@contextmanager
def connect(write=False):
    DATA.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DATA / 'wule.db', timeout=15)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA journal_mode=WAL')
    try:
        if write:
            db.execute('BEGIN IMMEDIATE')
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def init_db():
    with connect() as db:
        db.executescript((Path(__file__).with_name('schema.sql')).read_text(encoding='utf-8'))
        # 增量迁移：旧库 projects 表补充起止日期列。
        cols = {r['name'] for r in db.execute('PRAGMA table_info(projects)')}
        if 'started_on' not in cols:
            db.execute('ALTER TABLE projects ADD COLUMN started_on TEXT')
        if 'ended_on' not in cols:
            db.execute('ALTER TABLE projects ADD COLUMN ended_on TEXT')
        # 增量迁移：旧库 projects 表补充结项提醒阈值列（正数金额）。
        if 'alert_profit' not in cols:
            db.execute('ALTER TABLE projects ADD COLUMN alert_profit TEXT')
        if 'alert_loss' not in cols:
            db.execute('ALTER TABLE projects ADD COLUMN alert_loss TEXT')
        # 增量迁移：项目置顶标记（列表页优先排序+深色高亮）。
        if 'pinned' not in cols:
            db.execute("ALTER TABLE projects ADD COLUMN pinned INTEGER DEFAULT 0")
        # 增量迁移：operations 表补充定投计划关联列（定投生成的流水可追溯、可删除回退）。
        op_cols = {r['name'] for r in db.execute('PRAGMA table_info(operations)')}
        if 'plan_id' not in op_cols:
            db.execute('ALTER TABLE operations ADD COLUMN plan_id INTEGER')
        # 增量迁移：notifications 加 code 列（盯盘告警的股票代码）。
        n_cols = {r['name'] for r in db.execute('PRAGMA table_info(notifications)')}
        if 'code' not in n_cols:
            db.execute('ALTER TABLE notifications ADD COLUMN code TEXT')
        # Interrupted jobs are visible and retryable, never silently stuck.
        db.execute("UPDATE ocr_imports SET status='failed', error='服务重启，请重试识别' WHERE status IN ('queued','processing')")
        db.execute("UPDATE reports SET status='failed', error='服务重启，请重新导出' WHERE status IN ('queued','processing')")
