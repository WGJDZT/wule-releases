"""用户数据打包与恢复。

数据包 zip 结构：
- wule.db：账本数据库（用 sqlite3 backup API 生成 WAL 一致性快照，不直接复制库文件）
- uploads/**：OCR 截图等附件
- splash.mp4 / splash.webm：自定义开场视频（如有）

恢复时先把当前数据整体备份到 data/backups/，再原子替换数据库并覆盖附件，
最后执行 init_db() 让旧版本数据包也能套用增量迁移。
reports/ 为可再生的导出产物，backups/ 为恢复备份，均不打入数据包。
"""
import os
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

from . import db as _db
from .accounting import TZ

# 注意：必须经 _db.DATA 动态取数据目录（测试会 monkeypatch db.DATA），
# 严禁 from .db import DATA 绑定导入期常量，否则会写串到真实数据目录。

MAX_ZIP = 500 * 1024 * 1024  # 数据包大小上限 500MB
ATTACH_DIRS = ('uploads',)
ATTACH_FILES = ('splash.mp4', 'splash.webm')
DB_MAGIC = b'SQLite format 3\x00'


def snapshot_db(dest: Path):
    """WAL 模式下生成一致性快照到 dest（勿直接复制 db 文件）。"""
    with _db.connect() as src:
        dst = sqlite3.connect(dest)
        try:
            src.backup(dst)
        finally:
            dst.close()


def build_zip(dest: Path) -> dict:
    """打包当前用户数据到 dest，返回 {'files','size'}。"""
    tmp = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
    tmp.close()
    db_tmp = Path(tmp.name)
    files = 0
    try:
        snapshot_db(db_tmp)
        with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as z:
            z.write(db_tmp, 'wule.db')
            files += 1
            for d in ATTACH_DIRS:
                folder = _db.DATA / d
                if folder.is_dir():
                    for p in sorted(folder.rglob('*')):
                        if p.is_file():
                            z.write(p, f'{d}/{p.relative_to(folder).as_posix()}')
                            files += 1
            for name in ATTACH_FILES:
                p = _db.DATA / name
                if p.is_file():
                    z.write(p, name)
                    files += 1
        return {'files': files, 'size': dest.stat().st_size}
    finally:
        db_tmp.unlink(missing_ok=True)


def _validate(z: zipfile.ZipFile):
    names = z.namelist()
    if 'wule.db' not in names:
        raise ValueError('数据包缺少 wule.db，不是有效的数据包')
    with z.open('wule.db') as f:
        if f.read(16) != DB_MAGIC:
            raise ValueError('包内 wule.db 不是有效的 SQLite 数据库')
    for n in names:
        if n.startswith(('/', '\\')) or '..' in Path(n).parts:
            raise ValueError('数据包含非法路径，已拒绝')


def _checkpoint_wal():
    """恢复前把 WAL 全部写回库文件，避免替换后残留旧 wal/shm。"""
    for _ in range(5):
        with _db.connect() as db:
            row = db.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()
        if row and row[0] == 0:
            return


def restore_zip(src: Path) -> dict:
    """从数据包恢复：先备份当前数据，再替换数据库与附件。返回统计信息。"""
    if src.stat().st_size > MAX_ZIP:
        raise ValueError('数据包超过 500MB 上限')
    with zipfile.ZipFile(src) as z:
        _validate(z)
        restored = sum(1 for n in z.namelist() if not n.endswith('/'))
        # 1. 恢复前自动备份当前数据，误操作可回滚
        bak_dir = _db.DATA / 'backups'
        bak_dir.mkdir(parents=True, exist_ok=True)
        bak = bak_dir / f"pre-restore-{datetime.now(TZ):%Y%m%d-%H%M%S}.zip"
        build_zip(bak)
        # 2. 替换数据库（checkpoint + 原子替换 + 清残留 wal/shm）
        _checkpoint_wal()
        tmp = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
        tmp.close()
        db_tmp = Path(tmp.name)
        try:
            with z.open('wule.db') as fin, open(db_tmp, 'wb') as fout:
                while True:
                    chunk = fin.read(1024 * 1024)
                    if not chunk:
                        break
                    fout.write(chunk)
            os.replace(db_tmp, _db.DATA / 'wule.db')
        finally:
            db_tmp.unlink(missing_ok=True)
        for suffix in ('-wal', '-shm'):
            (_db.DATA / f'wule.db{suffix}').unlink(missing_ok=True)
        # 3. 覆盖附件目录与开场视频（恢复=整体回滚：包内没有的先清空）
        for d in ATTACH_DIRS:
            folder = _db.DATA / d
            members = [n for n in z.namelist() if n.startswith(f'{d}/') and not n.endswith('/')]
            if folder.exists():
                shutil.rmtree(folder)
            folder.mkdir(parents=True, exist_ok=True)
            for n in members:
                z.extract(n, _db.DATA)
        for name in ATTACH_FILES:
            p = _db.DATA / name
            p.unlink(missing_ok=True)
            if name in z.namelist():
                z.extract(name, _db.DATA)
    # 4. 旧版本数据包套用增量迁移
    _db.init_db()
    return {'files': restored, 'pre_backup': bak.name}
