PRAGMA user_version=1;
CREATE TABLE IF NOT EXISTS categories (
 id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, prefix TEXT NOT NULL UNIQUE
);
INSERT OR IGNORE INTO categories VALUES ('stock','股票','STK'),('fund','基金','FUND'),('other','其他','OTH'),('settle','平账项目','SETTLE');
CREATE TABLE IF NOT EXISTS projects (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL REFERENCES categories(id),
 code TEXT NOT NULL, instrument_name TEXT NOT NULL,
 quantity TEXT NOT NULL, cost_basis TEXT NOT NULL, current_price TEXT NOT NULL,
 previous_close TEXT, quote_at TEXT, realized_pnl TEXT NOT NULL DEFAULT '0',
 invested TEXT NOT NULL, proceeds TEXT NOT NULL DEFAULT '0',
 status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','closed')),
 started_on TEXT, ended_on TEXT,
 version INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, closed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_projects_filter ON projects(category,status,created_at);
CREATE INDEX IF NOT EXISTS idx_projects_code ON projects(code,status);
CREATE TABLE IF NOT EXISTS operations (
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_id TEXT NOT NULL REFERENCES projects(id),
 kind TEXT NOT NULL CHECK(kind IN ('open','buy','sell','close')),
 price TEXT NOT NULL, quantity TEXT NOT NULL, fee TEXT NOT NULL,
 realized_pnl TEXT NOT NULL, note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_operations_project ON operations(project_id,id);
CREATE TABLE IF NOT EXISTS settings (
 key TEXT PRIMARY KEY, value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications (
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_id TEXT REFERENCES projects(id),
 kind TEXT NOT NULL CHECK(kind IN ('profit','loss','system')),
 title TEXT NOT NULL, message TEXT NOT NULL, pnl TEXT,
 created_at TEXT NOT NULL, read_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(read_at,id);
CREATE TABLE IF NOT EXISTS investment_plans (
 id INTEGER PRIMARY KEY AUTOINCREMENT, project_id TEXT NOT NULL REFERENCES projects(id),
 amount TEXT NOT NULL, price TEXT NOT NULL,
 period TEXT NOT NULL CHECK(period IN ('weekly','biweekly','monthly')),
 next_run TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_investment_plans_due ON investment_plans(active,next_run);
CREATE INDEX IF NOT EXISTS idx_operations_time ON operations(created_at);
CREATE TABLE IF NOT EXISTS ledger_adjustments (
 id INTEGER PRIMARY KEY, amount TEXT NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS ledger_snapshots (
 id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT NOT NULL, category TEXT NOT NULL,
 principal TEXT NOT NULL, assets TEXT NOT NULL, pnl TEXT NOT NULL,
 created_at TEXT NOT NULL, UNIQUE(day,category)
);
CREATE TABLE IF NOT EXISTS goals (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL, period TEXT NOT NULL CHECK(period IN ('year','quarter','month')),
 project_id TEXT REFERENCES projects(id), target TEXT NOT NULL, starts_on TEXT NOT NULL,
 ends_on TEXT NOT NULL, baseline_pnl TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS goal_achievements (
 id INTEGER PRIMARY KEY, goal_id INTEGER NOT NULL REFERENCES goals(id),
 achieved_at TEXT NOT NULL, pnl TEXT NOT NULL, UNIQUE(goal_id)
);
CREATE TABLE IF NOT EXISTS strategies (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL, tags TEXT NOT NULL,
 trigger_conditions TEXT NOT NULL, buy_logic TEXT NOT NULL, sell_logic TEXT NOT NULL,
 position_rules TEXT NOT NULL, stop_loss TEXT NOT NULL, review TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS strategy_projects (
 strategy_id INTEGER NOT NULL REFERENCES strategies(id), project_id TEXT NOT NULL REFERENCES projects(id),
 PRIMARY KEY(strategy_id,project_id)
);
CREATE TABLE IF NOT EXISTS ocr_imports (
 id TEXT PRIMARY KEY, file_path TEXT NOT NULL, sha256 TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('queued','processing','review','confirmed','failed')),
 raw_text TEXT NOT NULL DEFAULT '', candidates TEXT NOT NULL DEFAULT '[]',
 confirmed_projects TEXT NOT NULL DEFAULT '[]', error TEXT, created_at TEXT NOT NULL, confirmed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_ocr_hash ON ocr_imports(sha256);
CREATE TABLE IF NOT EXISTS quote_cache (
 symbol TEXT PRIMARY KEY, name TEXT NOT NULL, price TEXT NOT NULL, previous_close TEXT,
 provider TEXT NOT NULL, market_at TEXT NOT NULL, fetched_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS reports (
 id TEXT PRIMARY KEY, format TEXT NOT NULL CHECK(format IN ('xlsx','pdf','png')),
 filters TEXT NOT NULL, status TEXT NOT NULL, file_path TEXT, error TEXT, created_at TEXT NOT NULL
);
