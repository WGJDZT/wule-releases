import asyncio
import hashlib
import io
import json
import mimetypes
import sqlite3
import subprocess
import tempfile
import threading
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path
from fastapi import FastAPI, File, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from pydantic import BaseModel, Field
from PIL import Image, UnidentifiedImageError
from .db import connect, init_db, DATA
from .models import ProjectCreate, ProjectDates, ProjectAlerts, OperationCreate, Adjustment, GoalCreate, GoalUpdate, StrategyCreate, ImportConfirm, ReportCreate, DipPlanCreate, DailyInclude
from .accounting import create_project, trade, project, serialize, ledger, snapshot, now, TZ, money, daily_series, day_detail, trade_metrics
from .alerts import check_alerts, save_alerts
from .dip import create_plan, delete_plan_operation, list_plans, run_due_plans, stop_plan
from . import secretary
from . import backup, cloud, updater
from .quotes import fetch_quote, refresh_quotes, quote_at
from .ocr import recognize,engine_status
from .reports import export_report
from . import watch as _watch

pool=ThreadPoolExecutor(max_workers=2,thread_name_prefix='wule')
slots=threading.BoundedSemaphore(8)
quote_lock=threading.Lock()
quote_state={'status':'idle','updated':0,'errors':[]}


def submit(fn,*args):
    if not slots.acquire(blocking=False):
        raise HTTPException(429,'后台队列已满，请稍后重试')
    def run():
        try:fn(*args)
        finally:slots.release()
    try:pool.submit(run)
    except Exception:
        slots.release();raise


def refresh_job():
    if not quote_lock.acquire(blocking=False):return
    quote_state.update(status='processing')
    try:
        quote_state.update(refresh_quotes(),status='ready',finished_at=now())
        with connect(True) as db:
            check_alerts(db)  # 行情刷新改变浮动盈亏，检测结项提示线
        _watch.check_watch_alerts()  # 自选股涨跌幅阈值告警
    except Exception as exc:
        quote_state.update(status='failed',errors=[{'error':str(exc)[:200]}],finished_at=now())
    finally:quote_lock.release()


def dip_job():
    with connect(True) as db:
        if run_due_plans(db):
            snapshot(db)


async def scheduler():
    """2 分钟周期调度：行情刷新 + 定投检查。"""
    while True:
        await asyncio.sleep(120)
        try:
            submit(refresh_job)
            submit(dip_job)
        except HTTPException:pass


@asynccontextmanager
async def lifespan(app):
    init_db()
    submit(dip_job)  # 启动即补齐停机期间到期的定投
    task=asyncio.create_task(scheduler())
    yield
    task.cancel()
    try:await task
    except asyncio.CancelledError:pass


app=FastAPI(title='我悟了投资管理有限公司',version='0.1.0',lifespan=lifespan)
# 本地个人系统：默认放行任意 Host（手机/局域网访问）；写操作仍由 local_origin 中间件保护。
app.add_middleware(TrustedHostMiddleware,allowed_hosts=['*'])


@app.middleware('http')
async def local_origin(request:Request, call_next):
    origin=request.headers.get('origin')
    if request.method not in ('GET','HEAD','OPTIONS') and origin:
        # 同源请求（页面自身提交）放行；否则仅允许本机开发端口白名单。
        same_origin=origin==f'{request.url.scheme}://{request.url.netloc}'
        if not same_origin and origin not in (
            'http://localhost:5173','http://127.0.0.1:5173','http://localhost:8000','http://127.0.0.1:8000'):
            return JSONResponse({'detail':'仅允许本机应用提交请求'},status_code=403)
    return await call_next(request)


@app.exception_handler(sqlite3.IntegrityError)
async def integrity_error(request,exc):
    return JSONResponse({'detail':'数据关联不存在或记录重复，请刷新后重试'},status_code=409)


@app.get('/api/health')
def health():return {'status':'ok','time':now(),'version':updater.VERSION}


# ===== 开场动画视频（存数据目录，不进 git/发布包，用户自行导入） =====
SPLASH_VIDEO_MAX=40*1024*1024  # 40MB


def splash_video_path():
    for ext in ('mp4','webm'):
        p=DATA/f'splash.{ext}'
        if p.exists():return p
    return None


@app.get('/api/splash/video/status')
def splash_video_status():
    """轻量探测：HEAD 请求自定义路由会 405，前端用此判断视频是否存在。"""
    p=splash_video_path()
    return {'exists':bool(p),'name':p.name if p else None}


@app.get('/api/splash/video')
def splash_video():
    p=splash_video_path()
    if not p:raise HTTPException(404,'未设置开场视频')
    return FileResponse(p,media_type='video/webm' if p.suffix=='.webm' else 'video/mp4')


@app.post('/api/splash/video')
async def upload_splash_video(file:UploadFile=File(...)):
    ext=(Path(file.filename or '').suffix or '').lower()
    if ext not in ('.mp4','.webm'):raise HTTPException(422,'仅支持 mp4 / webm 视频')
    data=await file.read()
    if not data:raise HTTPException(422,'视频内容为空')
    if len(data)>SPLASH_VIDEO_MAX:raise HTTPException(422,'视频不能超过 40MB')
    old=splash_video_path()
    if old:old.unlink()
    (DATA/f'splash{ext}').write_bytes(data)
    return {'saved':f'splash{ext}','size':len(data)}


@app.delete('/api/splash/video')
def remove_splash_video():
    p=splash_video_path()
    if p:p.unlink()
    return {'removed':bool(p)}


@app.get('/api/ocr/status')
def ocr_status():return engine_status()


@app.get('/api/market/insight')
def market_insight_api(refresh:int=0):
    """A股/美股热门板块涨跌幅；?refresh=1 强制刷新缓存。"""
    from .market import market_insight
    return market_insight(force=bool(refresh))


@app.get('/api/categories')
def categories():
    with connect() as db:return [dict(r) for r in db.execute('SELECT * FROM categories')]


class CategoryCreate(BaseModel):
    id:str=Field(pattern=r'^[a-z][a-z0-9_]{0,19}$')
    name:str=Field(min_length=1,max_length=30)
    prefix:str=Field(pattern=r'^[A-Z]{2,8}$')


@app.post('/api/categories',status_code=201)
def add_category(data:CategoryCreate):
    with connect(True) as db:db.execute('INSERT INTO categories VALUES(?,?,?)',(data.id,data.name,data.prefix))
    return data


@app.get('/api/projects')
def list_projects(q:str=Query('',max_length=100),category:str|None=None,status:str|None=None,
                  pnl:str|None=None,
                  page:int=Query(1,ge=1),page_size:int=Query(20,ge=1,le=100)):
    clauses,params=[],[]
    for key,value in [('category',category),('status',status)]:
        if value:clauses.append(key+'=?');params.append(value)
    if q:
        clauses.append('(name LIKE ? OR code LIKE ? OR instrument_name LIKE ?)');params += ['%'+q+'%']*3
    where=' WHERE '+' AND '.join(clauses) if clauses else ''
    with connect() as db:
        if pnl in ('profit','loss','flat'):
            # 盈亏状态基于派生字段 total_pnl，需逐条 serialize 后按 Decimal 符号过滤再分页。
            rows=db.execute('SELECT * FROM projects'+where+' ORDER BY COALESCE(pinned,0) DESC,created_at DESC,id DESC',params).fetchall()
            items=[serialize(r) for r in rows]
            sign={'profit':1,'loss':-1,'flat':0}[pnl]
            items=[x for x in items if _pnl_sign(Decimal(x['total_pnl']))==sign]
            total=len(items)
            items=items[(page-1)*page_size:(page-1)*page_size+page_size]
        else:
            total=db.execute('SELECT COUNT(*) FROM projects'+where,params).fetchone()[0]
            rows=db.execute('SELECT * FROM projects'+where+' ORDER BY COALESCE(pinned,0) DESC,created_at DESC,id DESC LIMIT ? OFFSET ?',params+[page_size,(page-1)*page_size]).fetchall()
            items=[serialize(r) for r in rows]
        for item in items:item['quote_at']=quote_at(item['code'],item['category'])
        return {'items':items,'total':total,'page':page,'page_size':page_size}


def _pnl_sign(value:Decimal)->int:
    return 1 if value>0 else (-1 if value<0 else 0)


@app.post('/api/projects',status_code=201)
def new_project(data:ProjectCreate):
    with connect(True) as db:
        result=create_project(db,data);snapshot(db);return result


@app.get('/api/projects/ranking')
def projects_ranking(category:str|None=None,status:str|None=None):
    """按累计盈亏降序返回全部项目（Decimal 精度排序），前端据此取盈/亏榜。"""
    with connect() as db:
        sql, args = 'SELECT id FROM projects', []
        if category:
            sql += ' WHERE category=?';args.append(category)
        if status in ('active','closed'):
            sql += ' WHERE ' if not args else ' AND '
            sql += 'status=?';args.append(status)
        rows=[serialize(project(db,r['id'])) for r in db.execute(sql,args).fetchall()]
    rows.sort(key=lambda x:Decimal(x['total_pnl']),reverse=True)
    return {'items':rows}


@app.patch('/api/projects/{pid}/pin')
def toggle_pin(pid:str):
    """切换项目置顶状态：置顶项目列表优先排序并深色高亮。"""
    with connect(True) as db:
        row=project(db,pid)
        db.execute('UPDATE projects SET pinned=? WHERE id=?',(0 if row['pinned'] else 1,pid))
        return serialize(project(db,pid))


@app.get('/api/projects/{pid}')
def get_project(pid:str):
    with connect() as db:
        row=project(db,pid)
        item=serialize(row);item['quote_at']=quote_at(item['code'],item['category'])
        item['trade_metrics']=trade_metrics(db,row)
        return item


@app.get('/api/projects/{pid}/operations')
def operations(pid:str,page:int=Query(1,ge=1),page_size:int=Query(20,ge=1,le=100)):
    with connect() as db:
        project(db,pid)
        rows=db.execute('SELECT * FROM operations WHERE project_id=? ORDER BY created_at DESC,id DESC LIMIT ? OFFSET ?',
                        (pid,page_size,(page-1)*page_size))
        return {'items':[dict(r) for r in rows],'total':db.execute('SELECT count(*) FROM operations WHERE project_id=?',(pid,)).fetchone()[0]}


@app.post('/api/projects/{pid}/operations',status_code=201)
def new_operation(pid:str,data:OperationCreate):
    with connect(True) as db:
        result=trade(db,pid,data);snapshot(db);check_alerts(db,pid);return result


class PriceUpdate(BaseModel):
    price:Decimal=Field(gt=0,max_digits=18,decimal_places=6)
    expected_version:int=Field(ge=1)


@app.patch('/api/projects/{pid}/price')
def set_price(pid:str,data:PriceUpdate):
    with connect(True) as db:
        row=project(db,pid)
        if row['status']=='closed':raise HTTPException(409,'已结项价格和盈亏已锁定')
        if row['version']!=data.expected_version:raise HTTPException(409,'项目已更新，请刷新')
        db.execute('UPDATE projects SET current_price=?,quote_at=?,version=version+1 WHERE id=?',(str(data.price),now(),pid))
        snapshot(db);check_alerts(db,pid);return serialize(project(db,pid))


@app.patch('/api/projects/{pid}/dates')
def set_dates(pid: str, data: ProjectDates):
    with connect() as db:
        row = project(db, pid)
        status, started, ended = row['status'], row['started_on'], row['ended_on']
    if data.ended_on is not None and status != 'closed':
        raise HTTPException(422, '未结项项目的结束日期由结项操作设置')
    if (data.started_on or started) and (data.ended_on or ended) \
            and (data.ended_on or ended) < (data.started_on or started):
        raise HTTPException(422, '结束日期不能早于开始日期')
    with connect(True) as db:
        current = project(db, pid)
        if current['version'] != data.expected_version:
            raise HTTPException(409, '项目已更新，请刷新后重试')
        fields, args = [], []
        if data.started_on is not None:
            fields.append('started_on=?')
            args.append(data.started_on.isoformat())
        if data.ended_on is not None:
            fields.append('ended_on=?')
            args.append(data.ended_on.isoformat())
        if not fields:
            raise HTTPException(422, '未提供需要修改的日期')
        db.execute(f"UPDATE projects SET {','.join(fields)},version=version+1 WHERE id=?", (*args, pid))
    with connect() as db:
        return serialize(project(db, pid))


@app.patch('/api/projects/{pid}/daily-include')
def set_daily_include(pid: str, data: DailyInclude):
    # 平账项目当日盈亏口径开关：include=True 计入当日盈亏，False 排除（默认）。
    # 仅改口径标记，不动账务数据；今日盈亏为实时计算，无需重算快照。
    with connect(True) as db:
        row = project(db, pid)
        if row['category'] != 'settle':
            raise HTTPException(422, '仅平账项目支持设置当日盈亏口径')
        db.execute('UPDATE projects SET skip_daily=? WHERE id=?', (0 if data.include else 1, pid))
        return serialize(project(db, pid))


@app.delete('/api/projects/{pid}')
def remove_project(pid:str):
    with connect(True) as db:
        row=project(db,pid)
        # 引用先清理再删项目：外键已开启，同事务原子回滚。
        db.execute('DELETE FROM operations WHERE project_id=?',(pid,))
        db.execute('DELETE FROM strategy_projects WHERE project_id=?',(pid,))
        db.execute('DELETE FROM notifications WHERE project_id=?',(pid,))
        db.execute('DELETE FROM investment_plans WHERE project_id=?',(pid,))
        db.execute('UPDATE goals SET project_id=NULL WHERE project_id=?',(pid,))
        db.execute('DELETE FROM projects WHERE id=?',(pid,))
        snapshot(db)
    return {'deleted':pid,'name':row['name']}


@app.get('/api/projects/{pid}/dip-plans')
def dip_plans(pid:str):
    with connect() as db:return {'items':list_plans(db,pid)}


@app.post('/api/projects/{pid}/dip-plans',status_code=201)
def dip_plan_create(pid:str,data:DipPlanCreate):
    with connect(True) as db:return create_plan(db,pid,data)


@app.delete('/api/projects/{pid}/dip-plans/{plan_id}')
def dip_plan_stop(pid:str,plan_id:int):
    with connect(True) as db:return stop_plan(db,pid,plan_id)


@app.delete('/api/projects/{pid}/operations/{operation_id}')
def dip_operation_delete(pid:str,operation_id:int):
    with connect(True) as db:
        result=delete_plan_operation(db,pid,operation_id);snapshot(db);return result


@app.post('/api/dip/run-due')
def dip_run_due():
    with connect(True) as db:
        executed=run_due_plans(db)
        if executed:snapshot(db)
    return {'executed':executed}


@app.get('/api/ledger')
def totals(category:str|None=None):
    with connect() as db:return ledger(db,category)


@app.post('/api/ledger/adjustments',status_code=201)
def adjustment(data:Adjustment):
    with connect(True) as db:
        db.execute('INSERT INTO ledger_adjustments(amount,reason,created_at) VALUES(?,?,?)',(str(data.amount),data.reason,now()))
        snapshot(db);return ledger(db)


@app.get('/api/ledger/adjustments')
def adjustments(page:int=Query(1,ge=1),page_size:int=Query(20,ge=1,le=100)):
    with connect() as db:
        return {'items':[dict(r) for r in db.execute('SELECT * FROM ledger_adjustments ORDER BY id DESC LIMIT ? OFFSET ?',
            (page_size,(page-1)*page_size))],'total':db.execute('SELECT count(*) FROM ledger_adjustments').fetchone()[0]}


@app.get('/api/ledger/series')
def series(category:str='all',since:str='',limit:int=Query(366,ge=1,le=1000)):
    with connect() as db:
        rows=[dict(r) for r in db.execute('SELECT * FROM ledger_snapshots WHERE category=? AND created_at>? ORDER BY created_at,id LIMIT ?',
                                         (category,since,limit))]
    return {'items':rows,'cursor':rows[-1]['created_at'] if rows else since,'has_more':len(rows)==limit}


@app.get('/api/ledger/daily')
def daily(from_: str = Query(..., alias='from'), to: str = Query(...), category: str='all'):
    try:
        start, end = date.fromisoformat(from_), date.fromisoformat(to)
    except ValueError:
        raise HTTPException(422, '日期格式应为YYYY-MM-DD')
    if start > end:
        raise HTTPException(422, '开始日期不能晚于结束日期')
    if (end - start).days > 366:
        raise HTTPException(422, '日期跨度不能超过366天')
    with connect() as db:
        return {'items': daily_series(db, from_, to, category)}


@app.get('/api/ledger/periods')
def periods():
    # 本周/本月/本年盈亏：期末取实时总盈亏，期初取起点前最近快照；无基准为 null（不伪造数据）。
    today=datetime.now(TZ).date()
    marks={'week':today-timedelta(days=today.weekday()),'month':today.replace(day=1),
           'year':today.replace(month=1,day=1)}
    with connect() as db:
        current=Decimal(ledger(db)['pnl'])
        out={}
        for key,start in marks.items():
            base=db.execute("SELECT pnl FROM ledger_snapshots WHERE category='all' AND day<? ORDER BY day DESC LIMIT 1",
                            (start.isoformat(),)).fetchone()
            # 周期内盈亏排除周期内创建的平账项目（skip_daily=1），与今日盈亏口径一致。
            settle=sum((Decimal(r[0]) for r in db.execute(
                "SELECT realized_pnl FROM projects WHERE category='settle' AND skip_daily=1 AND created_at>=?",
                (start.isoformat(),))),Decimal('0'))
            out[key]=money(current-Decimal(base['pnl'])-settle) if base else None
        return out


@app.get('/api/ledger/daily/{day}')
def daily_detail(day: str, category: str = 'all'):
    try:
        date.fromisoformat(day)
    except ValueError:
        raise HTTPException(422, '日期格式应为YYYY-MM-DD')
    with connect() as db:
        return day_detail(db, day, category)


@app.get('/api/secretary/settings')
def secretary_settings():
    return secretary.get_settings()


@app.post('/api/secretary/settings')
def secretary_save(data: dict):
    key = data.get('api_key')
    secretary.save_settings(data.get('base_url', ''), data.get('model', ''),
                            None if key is None else str(key))
    return secretary.get_settings()


@app.post('/api/secretary/chat')
def secretary_chat(data: dict):
    msgs = data.get('messages') or []
    if not msgs or msgs[-1].get('role') != 'user':
        raise HTTPException(422, '最后一条消息必须是用户发言')
    try:
        reply, steps = secretary.chat(msgs[-40:])
    except PermissionError as e:
        raise HTTPException(400, str(e))
    except RuntimeError as e:
        raise HTTPException(502, str(e))
    return {'reply': reply, 'steps': steps}


@app.get('/api/backup')
def backup_download():
    # WAL 模式下用 sqlite3 backup API 生成一致性快照；响应发送完成后删除临时文件。
    import tempfile
    from starlette.background import BackgroundTask
    tmp=tempfile.NamedTemporaryFile(suffix='.db',delete=False);tmp.close()
    with connect() as src:
        dst=sqlite3.connect(tmp.name)
        src.backup(dst)
        dst.close()
    name='wule-backup-'+datetime.now(TZ).strftime('%Y%m%d-%H%M')+'.db'
    return FileResponse(tmp.name,filename=name,media_type='application/octet-stream',
        background=BackgroundTask(Path(tmp.name).unlink))


@app.get('/api/watchlist')
def watch_list():
    """自选股列表（含实时快照：名称/现价/涨跌幅/行情时间）。"""
    items = _watch.load()
    enriched = []
    for w in items:
        snap = _watch.snapshot(w['code'])
        enriched.append({**w,
                         'name': snap.get('name') or w['name'],
                         'price': snap.get('price'),
                         'change_pct': snap.get('change_pct'),
                         'market_at': snap.get('market_at'),
                         'error': snap.get('error'),
                         })
    return enriched


class WatchAdd(BaseModel):
    code: str = Field(pattern=r'^\d{6}$')
    name: str = ''
    upper_pct: float = 3.0
    lower_pct: float = -3.0
    enabled: bool = True


@app.post('/api/watchlist', status_code=201)
def watch_add(data: WatchAdd):
    try:
        name = data.name.strip() or _watch.snapshot(data.code).get('name') or data.code
    except Exception:
        name = data.code
    return _watch.upsert(data.code, name=name, upper_pct=data.upper_pct,
                         lower_pct=data.lower_pct, enabled=data.enabled)


@app.put('/api/watchlist/{code}')
def watch_update(code: str, data: WatchAdd):
    if data.code != code: raise HTTPException(422, '代码不一致')
    return _watch.upsert(code, name=data.name, upper_pct=data.upper_pct,
                         lower_pct=data.lower_pct, enabled=data.enabled)


@app.delete('/api/watchlist/{code}')
def watch_delete(code: str):
    return _watch.remove(code)


@app.get('/api/watchlist/{code}')
def watch_detail(code: str, refresh: int = 0):
    """单只自选的聚合详情：实时 + 盘中分时 + 日 K。"""
    try:
        return _watch.detail(code, force=bool(refresh))
    except ValueError as e:
        raise HTTPException(404, str(e))


@app.post('/api/watchlist/check')
def watch_check():
    hits = _watch.check_watch_alerts()
    return {'hits': hits}


@app.get('/api/backup/zip')
def backup_zip_download():
    # 数据包：wule.db 一致性快照 + uploads/ 附件 + 开场视频；响应完成后删临时文件。
    from starlette.background import BackgroundTask
    tmp=tempfile.NamedTemporaryFile(suffix='.zip',delete=False);tmp.close()
    try:
        backup.build_zip(Path(tmp.name))
    except Exception:
        Path(tmp.name).unlink(missing_ok=True);raise
    name='wule-data-'+datetime.now(TZ).strftime('%Y%m%d-%H%M')+'.zip'
    return FileResponse(tmp.name,filename=name,media_type='application/zip',
        background=BackgroundTask(Path(tmp.name).unlink))


@app.post('/api/backup/restore')
async def backup_restore(file:UploadFile=File(...)):
    data=await file.read()
    if len(data)>backup.MAX_ZIP:raise HTTPException(413,'数据包超过 500MB 上限')
    tmp=tempfile.NamedTemporaryFile(suffix='.zip',delete=False);tmp.write(data);tmp.close()
    try:
        stats=backup.restore_zip(Path(tmp.name))
    except ValueError as e:
        raise HTTPException(422,str(e))
    except zipfile.BadZipFile:
        raise HTTPException(422,'文件不是有效的 zip 数据包')
    finally:
        Path(tmp.name).unlink(missing_ok=True)
    return {'restored':True,**stats}


@app.get('/api/cloud/settings')
def cloud_settings():
    return cloud.get_settings()


@app.post('/api/cloud/settings')
def cloud_save(data: dict):
    token=data.get('token')
    cloud.save_settings(data.get('repo',''),None if token is None else str(token))
    return cloud.get_settings()


@app.post('/api/cloud/push')
def cloud_push():
    try:return cloud.push()
    except PermissionError as e:raise HTTPException(400,str(e))
    except RuntimeError as e:raise HTTPException(502,str(e))


@app.post('/api/cloud/pull')
def cloud_pull():
    try:return cloud.pull()
    except PermissionError as e:raise HTTPException(400,str(e))
    except ValueError as e:raise HTTPException(422,str(e))
    except RuntimeError as e:raise HTTPException(502,str(e))


@app.get('/api/update/check')
def update_check():
    return updater.check()


@app.post('/api/update/apply')
def update_apply():
    try:return updater.apply_update()
    except RuntimeError as e:raise HTTPException(502,str(e))


@app.post('/api/update/restart')
def update_restart():
    cmd=updater.restart_command()
    if not cmd:return {'restarting':False,'message':'当前环境请手动重启应用'}
    subprocess.Popen(cmd,cwd=str(updater.ROOT))
    return {'restarting':True}


@app.get('/api/quotes/status')
def refresh_status():
    with connect() as db:
        row=db.execute('SELECT max(fetched_at) fetched,max(market_at) market FROM quote_cache').fetchone()
    return {**quote_state,'latest_fetched_at':row['fetched'],'latest_market_at':row['market']}


@app.get('/api/quotes/{code}')
def quote(code:str,category:str='stock'):
    try:return fetch_quote(code,category)
    except Exception as exc:raise HTTPException(502,str(exc)[:200]) from exc


@app.post('/api/quotes/refresh',status_code=202)
def refresh():
    if quote_state['status']!='processing':submit(refresh_job)
    return quote_state


@app.post('/api/projects/{pid}/alerts')
def set_alerts(pid:str,data:ProjectAlerts):
    try:
        with connect(True) as db:
            project(db,pid)  # 404 校验
            save_alerts(db,pid,str(data.alert_profit) if data.alert_profit is not None else None,
                        str(data.alert_loss) if data.alert_loss is not None else None)
    except InvalidOperation as exc:
        raise HTTPException(422,'提示线金额格式不正确')
    except ValueError as exc:
        raise HTTPException(422,str(exc))
    with connect() as db:
        return serialize(project(db,pid))


@app.get('/api/notifications/unread-count')
def notifications_unread():
    with connect() as db:
        return {'unread':db.execute('SELECT count(*) FROM notifications WHERE read_at IS NULL').fetchone()[0]}


@app.get('/api/notifications')
def notifications_list(page:int=Query(1,ge=1),page_size:int=Query(20,ge=1,le=100)):
    # 读取列表前先兜底检测一遍，保证通知及时性。
    with connect(True) as db:
        check_alerts(db)
    with connect() as db:
        total=db.execute('SELECT count(*) FROM notifications').fetchone()[0]
        rows=db.execute('SELECT n.*,p.name project_name,p.code project_code FROM notifications n '
                        'LEFT JOIN projects p ON p.id=n.project_id ORDER BY n.id DESC LIMIT ? OFFSET ?',
                        (page_size,(page-1)*page_size)).fetchall()
        return {'items':[dict(r) for r in rows],'total':total,
                'unread':db.execute('SELECT count(*) FROM notifications WHERE read_at IS NULL').fetchone()[0]}


@app.post('/api/notifications/read-all')
def notifications_read_all():
    with connect(True) as db:
        n=db.execute("UPDATE notifications SET read_at=? WHERE read_at IS NULL",(now(),)).rowcount
    return {'read':n}


@app.post('/api/imports',status_code=202)
def upload(file:UploadFile=File(...)):
    content=file.file.read(10*1024*1024+1)
    if len(content)>10*1024*1024:raise HTTPException(413,'图片不得超过10MB')
    try:
        with Image.open(io.BytesIO(content)) as image:
            if image.format not in ('PNG','JPEG','WEBP'):raise ValueError('仅支持PNG、JPEG、WebP')
            if image.width*image.height>20_000_000:raise ValueError('图片不得超过2000万像素')
            image.verify()
            suffix={'PNG':'.png','JPEG':'.jpg','WEBP':'.webp'}[image.format]
    except (UnidentifiedImageError,OSError,ValueError,Image.DecompressionBombError) as exc:
        raise HTTPException(422,'无效图片：'+str(exc)) from exc
    key=uuid.uuid4().hex
    folder=DATA/'uploads';folder.mkdir(parents=True,exist_ok=True)
    path=folder/(key+suffix);path.write_bytes(content)
    with connect(True) as db:
        db.execute("INSERT INTO ocr_imports(id,file_path,sha256,status,created_at) VALUES(?,?,?,'queued',?)",
                   (key,str(path),hashlib.sha256(content).hexdigest(),now()))
    try:submit(recognize,key)
    except HTTPException:
        with connect(True) as db:db.execute("UPDATE ocr_imports SET status='failed',error='后台队列已满，请重试' WHERE id=?",(key,))
    return {'id':key,'status':'queued'}


def import_row(db,key):
    row=db.execute('SELECT * FROM ocr_imports WHERE id=?',(key,)).fetchone()
    if not row:raise HTTPException(404,'导入记录不存在')
    return row


def import_json(row):
    result=dict(row);result.pop('file_path',None)
    for k in ('candidates','confirmed_projects'):result[k]=json.loads(result[k])
    return result


@app.get('/api/imports')
def imports(page:int=Query(1,ge=1),page_size:int=Query(20,ge=1,le=100)):
    with connect() as db:
        return {'items':[import_json(r) for r in db.execute('SELECT * FROM ocr_imports ORDER BY created_at DESC LIMIT ? OFFSET ?',
                        (page_size,(page-1)*page_size))],'total':db.execute('SELECT count(*) FROM ocr_imports').fetchone()[0]}


@app.get('/api/imports/{key}')
def get_import(key:str):
    with connect() as db:return import_json(import_row(db,key))


@app.get('/api/imports/{key}/image')
def import_image(key:str):
    with connect() as db:path=import_row(db,key)['file_path']
    return FileResponse(path,headers={'Cache-Control':'no-store'})


@app.post('/api/imports/{key}/retry',status_code=202)
def retry_import(key:str):
    with connect() as db:
        row=import_row(db,key)
        if row['status']!='failed':raise HTTPException(409,'只有失败任务可以重试')
    submit(recognize,key);return {'id':key,'status':'queued'}


@app.post('/api/imports/{key}/confirm',status_code=201)
def confirm_import(key:str,data:ImportConfirm):
    with connect(True) as db:
        row=import_row(db,key)
        if row['status']=='confirmed':return {'project_ids':json.loads(row['confirmed_projects']),'already_confirmed':True}
        if row['status']!='review':raise HTTPException(409,'识别完成并核对后才能入库')
        ids=[create_project(db,p)['id'] for p in data.projects]
        db.execute("UPDATE ocr_imports SET status='confirmed',confirmed_projects=?,confirmed_at=? WHERE id=?",(json.dumps(ids),now(),key))
        snapshot(db);return {'project_ids':ids,'already_confirmed':False}


def goal_progress(db,row):
    item=dict(row)
    pnl=Decimal(serialize(project(db,row['project_id']))['total_pnl']) if row['project_id'] else Decimal(ledger(db)['pnl'])
    current=pnl-Decimal(row['baseline_pnl']);today=datetime.now(TZ).date()
    remaining=(datetime.fromisoformat(row['ends_on']).date()-today).days
    achieved=current>=Decimal(row['target'])
    return dict(item,current_pnl=money(current),completion_percent=str(current/Decimal(row['target'])*100),
                remaining_days=max(0,remaining),achieved=achieved,
                reminder='目标已达成' if achieved else '目标已到期' if remaining<0 else '距离截止不足7天' if remaining<=7 else '')


@app.post('/api/goals',status_code=201)
def create_goal(data:GoalCreate):
    with connect(True) as db:
        baseline=serialize(project(db,data.project_id))['total_pnl'] if data.project_id else ledger(db)['pnl']
        row=db.execute('''INSERT INTO goals(name,period,project_id,target,starts_on,ends_on,baseline_pnl,created_at)
            VALUES(?,?,?,?,?,?,?,?)''',(data.name,data.period,data.project_id,str(data.target),data.starts_on.isoformat(),data.ends_on.isoformat(),baseline,now()))
        return goal_progress(db,db.execute('SELECT * FROM goals WHERE id=?',(row.lastrowid,)).fetchone())


@app.get('/api/goals')
def goals(page:int=Query(1,ge=1),page_size:int=Query(20,ge=1,le=100)):
    with connect(True) as db:
        items=[goal_progress(db,r) for r in db.execute('SELECT * FROM goals ORDER BY id DESC LIMIT ? OFFSET ?',(page_size,(page-1)*page_size))]
        for item in items:
            if item['achieved']:
                db.execute('INSERT OR IGNORE INTO goal_achievements(goal_id,achieved_at,pnl) VALUES(?,?,?)',(item['id'],now(),item['current_pnl']))
            history=db.execute('SELECT achieved_at FROM goal_achievements WHERE goal_id=?',(item['id'],)).fetchone()
            item['first_achieved_at']=history['achieved_at'] if history else None
        return {'items':items,'total':db.execute('SELECT count(*) FROM goals').fetchone()[0]}


@app.patch('/api/goals/{gid}')
def update_goal(gid:int,data:GoalUpdate):
    with connect(True) as db:
        row=db.execute('SELECT * FROM goals WHERE id=?',(gid,)).fetchone()
        if not row:raise HTTPException(404,'目标不存在')
        name=data.name if data.name is not None else row['name']
        period=data.period if data.period is not None else row['period']
        target=str(data.target) if data.target is not None else row['target']
        starts_on=data.starts_on.isoformat() if data.starts_on else row['starts_on']
        ends_on=data.ends_on.isoformat() if data.ends_on else row['ends_on']
        if ends_on<starts_on:raise HTTPException(422,'结束日期不能早于开始日期')
        project_id=data.project_id if data.project_id is not None else row['project_id']
        baseline=row['baseline_pnl']
        if project_id!=row['project_id']:
            # 更换绑定对象时基线重算为新对象当前累计盈亏，完成率从零重新衡量。
            baseline=serialize(project(db,project_id))['total_pnl'] if project_id else ledger(db)['pnl']
        db.execute('''UPDATE goals SET name=?,period=?,project_id=?,target=?,starts_on=?,ends_on=?,baseline_pnl=? WHERE id=?''',
                   (name,period,project_id,target,starts_on,ends_on,baseline,gid))
        return goal_progress(db,db.execute('SELECT * FROM goals WHERE id=?',(gid,)).fetchone())


@app.delete('/api/goals/{gid}')
def remove_goal(gid:int):
    with connect(True) as db:
        row=db.execute('SELECT * FROM goals WHERE id=?',(gid,)).fetchone()
        if not row:raise HTTPException(404,'目标不存在')
        # 外键已开启，同事务级联清理达成记录，原子回滚。
        db.execute('DELETE FROM goal_achievements WHERE goal_id=?',(gid,))
        db.execute('DELETE FROM goals WHERE id=?',(gid,))
    return {'deleted':gid,'name':row['name']}


@app.post('/api/strategies',status_code=201)
def create_strategy(data:StrategyCreate):
    with connect(True) as db:
        row=db.execute('''INSERT INTO strategies(name,tags,trigger_conditions,buy_logic,sell_logic,position_rules,stop_loss,review,created_at)
            VALUES(?,?,?,?,?,?,?,?,?)''',(data.name,json.dumps(data.tags,ensure_ascii=False),data.trigger_conditions,data.buy_logic,data.sell_logic,data.position_rules,data.stop_loss,data.review,now()))
        for pid in set(data.project_ids):
            project(db,pid);db.execute('INSERT INTO strategy_projects VALUES(?,?)',(row.lastrowid,pid))
        return {'id':row.lastrowid,**data.model_dump()}


@app.put('/api/strategies/{sid}')
def update_strategy(sid:int,data:StrategyCreate):
    with connect(True) as db:
        if not db.execute('SELECT 1 FROM strategies WHERE id=?',(sid,)).fetchone():raise HTTPException(404,'策略不存在')
        db.execute('''UPDATE strategies SET name=?,tags=?,trigger_conditions=?,buy_logic=?,sell_logic=?,position_rules=?,stop_loss=?,review=? WHERE id=?''',
                   (data.name,json.dumps(data.tags,ensure_ascii=False),data.trigger_conditions,data.buy_logic,data.sell_logic,data.position_rules,data.stop_loss,data.review,sid))
        db.execute('DELETE FROM strategy_projects WHERE strategy_id=?',(sid,))
        for pid in set(data.project_ids):
            project(db,pid);db.execute('INSERT INTO strategy_projects VALUES(?,?)',(sid,pid))
        return {'id':sid,**data.model_dump()}


@app.get('/api/strategies')
def strategies(q:str=Query('',max_length=100),project_id:str|None=None,page:int=Query(1,ge=1),page_size:int=Query(20,ge=1,le=100)):
    with connect() as db:
        clauses,params=[],[]
        if q:clauses.append('(name LIKE ? OR tags LIKE ?)');params += ['%'+q+'%']*2
        if project_id:clauses.append('id IN (SELECT strategy_id FROM strategy_projects WHERE project_id=?)');params.append(project_id)
        where=' WHERE '+' AND '.join(clauses) if clauses else ''
        items=[]
        for row in db.execute('SELECT * FROM strategies'+where+' ORDER BY id DESC LIMIT ? OFFSET ?',params+[page_size,(page-1)*page_size]):
            item=dict(row);item['tags']=json.loads(item['tags'])
            item['project_ids']=[r[0] for r in db.execute('SELECT project_id FROM strategy_projects WHERE strategy_id=?',(row['id'],))]
            item['project_names']=[{'id':r[0],'name':r[1]} for r in db.execute(
                'SELECT sp.project_id,p.name FROM strategy_projects sp JOIN projects p ON p.id=sp.project_id WHERE sp.strategy_id=?',(row['id'],))]
            items.append(item)
        return {'items':items,'total':db.execute('SELECT count(*) FROM strategies'+where,params).fetchone()[0],
                'page':page,'page_size':page_size}


@app.post('/api/reports',status_code=202)
def new_report(data:ReportCreate):
    key=uuid.uuid4().hex
    with connect(True) as db:
        db.execute("INSERT INTO reports(id,format,filters,status,created_at) VALUES(?,?,?,'queued',?)",(key,data.format,data.model_dump_json(),now()))
    try:submit(export_report,key)
    except HTTPException:
        with connect(True) as db:db.execute("UPDATE reports SET status='failed',error='后台队列已满，请重新导出' WHERE id=?",(key,))
    return {'id':key,'status':'queued'}


@app.get('/api/reports')
def reports(page:int=Query(1,ge=1),page_size:int=Query(20,ge=1,le=100)):
    with connect() as db:
        return {'items':[dict(r) for r in db.execute('SELECT id,format,filters,status,error,created_at FROM reports ORDER BY created_at DESC LIMIT ? OFFSET ?',
                        (page_size,(page-1)*page_size))],'total':db.execute('SELECT count(*) FROM reports').fetchone()[0]}


@app.get('/api/reports/{key}')
def get_report(key:str):
    with connect() as db:
        row=db.execute('SELECT id,format,filters,status,error,created_at FROM reports WHERE id=?',(key,)).fetchone()
        if not row:raise HTTPException(404,'财报不存在')
        return dict(row)


@app.get('/api/reports/{key}/download')
def download(key:str):
    with connect() as db:row=db.execute('SELECT * FROM reports WHERE id=?',(key,)).fetchone()
    if not row:raise HTTPException(404,'财报不存在')
    if row['status']!='ready':raise HTTPException(409,'财报尚未生成')
    return FileResponse(row['file_path'],filename='wule-report-'+key[:8]+'.'+row['format'],headers={'Cache-Control':'no-store'})


# Production build: same origin API + SPA. Run Vite separately during development.
dist=Path(__file__).resolve().parents[2]/'frontend'/'dist'
if dist.exists():
    # Windows registry may map .js to text/plain; module scripts require JS MIME.
    mimetypes.add_type('text/javascript','.js')
    mimetypes.add_type('text/javascript','.mjs')
    mimetypes.add_type('text/css','.css')
    from fastapi.staticfiles import StaticFiles
    app.mount('/assets',StaticFiles(directory=dist/'assets'),name='assets')
    @app.get('/{path:path}',include_in_schema=False)
    def spa(path:str):
        if path.startswith('api/'):raise HTTPException(404,'接口不存在')
        return FileResponse(dist/'index.html')
