from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from fastapi import HTTPException
from .models import ProjectCreate, OperationCreate

TZ = timezone(timedelta(hours=8))
D = Decimal
ZERO = D('0')


def now():
    return datetime.now(TZ).isoformat(timespec='microseconds')


def money(value):
    return str(D(value).quantize(D('.01'), rounding=ROUND_HALF_UP))


def project(db, project_id):
    row = db.execute('SELECT * FROM projects WHERE id=?', (project_id,)).fetchone()
    if not row:
        raise HTTPException(404, '项目不存在')
    return row


def serialize(row):
    item = dict(row)
    qty, basis, price = map(D, (item['quantity'], item['cost_basis'], item['current_price']))
    item.update(cost_price=str(basis / qty) if qty else '0', market_value=money(qty * price),
                unrealized_pnl=money(qty * price - basis),
                total_pnl=money(qty * price - basis + D(item['realized_pnl'])))
    if item['category'] == 'settle':
        # 平账项目：proceeds 非零表示创建时勾选了“计入总资产”。
        item['count_assets'] = D(item['proceeds']) != 0
        item['skip_daily'] = bool(item['skip_daily'])
    return item


def create_project(db, data: ProjectCreate):
    cat = db.execute('SELECT prefix FROM categories WHERE id=?', (data.category,)).fetchone()
    if not cat:
        raise HTTPException(422, '资产类别不存在')
    stamp = now()
    prefix = f"{cat['prefix']}-{datetime.now(TZ):%Y%m%d}-"
    # Caller holds BEGIN IMMEDIATE; sequence allocation and insert share the lock.
    last = db.execute('SELECT id FROM projects WHERE id LIKE ? ORDER BY LENGTH(id) DESC,id DESC LIMIT 1', (prefix+'%',)).fetchone()
    seq = int(last['id'].rsplit('-', 1)[1]) + 1 if last else 1
    pid = f'{prefix}{seq:03d}'
    started = (data.started_on or date.fromisoformat(stamp[:10])).isoformat()
    if data.category == 'settle':
        # 平账项目：不绑定标的、只有盈亏金额、默认结项。
        # 默认口径（count_assets=False）：盈亏冲减/回补累计本金（invested=-amount），
        # 总资产不变，总盈亏=资产-本金 自然变化 amount。
        # 勾选用计入总资产（count_assets=True）：回款记为盈亏额（proceeds=amount），本金不变。
        amount = data.settle_pnl
        invested, proceeds = (D('0'), amount) if data.count_assets else (-amount, D('0'))
        db.execute('''INSERT INTO projects(id,name,category,code,instrument_name,quantity,cost_basis,
            current_price,invested,proceeds,realized_pnl,status,started_on,ended_on,created_at,closed_at,skip_daily)
            VALUES(?,?,?,'-','平账','0','0','0',?,?,?,'closed',?,?,?,?,?)''',
            (pid,data.name,data.category,str(invested),str(proceeds),str(amount),started,started,stamp,stamp,1 if data.skip_daily else 0))
        db.execute('''INSERT INTO operations(project_id,kind,price,quantity,fee,realized_pnl,note,created_at)
            VALUES(?,'close','0','0','0',?,?,?)''', (pid,str(amount),data.note,stamp))
        return serialize(project(db, pid))
    basis = data.price * data.quantity + data.fee
    db.execute('''INSERT INTO projects(id,name,category,code,instrument_name,quantity,cost_basis,
        current_price,invested,started_on,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
        (pid,data.name,data.category,data.code,data.instrument_name,str(data.quantity),str(basis),str(data.current_price or data.price),str(basis),started,stamp))
    db.execute('''INSERT INTO operations(project_id,kind,price,quantity,fee,realized_pnl,note,created_at)
        VALUES(?,?,?,?,?,?,?,?)''', (pid,'open',str(data.price),str(data.quantity),str(data.fee),'0',data.note,stamp))
    return serialize(project(db, pid))


def trade(db, pid: str, data: OperationCreate, plan_id: int | None = None):
    row = project(db, pid)
    if row['status'] == 'closed':
        raise HTTPException(409, '已结项项目禁止继续操作')
    if row['version'] != data.expected_version:
        raise HTTPException(409, '项目已更新，请刷新后重试')
    qty, basis, realized, invested, proceeds = map(D, (row['quantity'],row['cost_basis'],row['realized_pnl'],row['invested'],row['proceeds']))
    delta = ZERO
    if data.kind == 'buy':
        basis += data.price * data.quantity + data.fee
        invested += data.price * data.quantity + data.fee
        qty += data.quantity
    else:
        if data.quantity > qty or (data.kind == 'close' and data.quantity != qty):
            raise HTTPException(422, '卖出数量超出持仓，或结项未卖出全部持仓')
        removed = basis if data.quantity == qty else basis * data.quantity / qty
        net = data.price * data.quantity - data.fee
        delta = net - removed
        realized += delta
        proceeds += net
        basis -= removed
        qty -= data.quantity
    closed = qty == 0
    stamp = now()
    ended = None
    if closed:
        ended = (data.ended_on or date.fromisoformat(stamp[:10])).isoformat()
        started = row['started_on']
        if started and ended < started:
            raise HTTPException(422, '结束日期不能早于开始日期')
    db.execute('''UPDATE projects SET quantity=?,cost_basis=?,realized_pnl=?,invested=?,proceeds=?,
        current_price=?,status=?,closed_at=?,ended_on=?,version=version+1 WHERE id=?''',
        (str(qty),str(basis),str(realized),str(invested),str(proceeds),str(data.price),
         'closed' if closed else 'active',stamp if closed else None,ended,pid))
    # 操作记录时间：补录历史时用指定的成交时间，否则取当前；账务快照仍以落账时刻为准。
    operated_at = data.executed_at.isoformat() if data.executed_at else stamp
    db.execute('''INSERT INTO operations(project_id,kind,price,quantity,fee,realized_pnl,note,created_at,plan_id)
        VALUES(?,?,?,?,?,?,?,?,?)''', (pid,data.kind,str(data.price),str(data.quantity),str(data.fee),str(delta),data.note,operated_at,plan_id))
    return serialize(project(db,pid))


def ledger(db, category=None):
    rows = db.execute('SELECT * FROM projects' + (' WHERE category=?' if category else ''), (category,) if category else ()).fetchall()
    principal = assets = realized = floating = ZERO
    distribution = {}
    pnl_by_category = {}
    for row in rows:
        qty,basis,price = map(D,(row['quantity'],row['cost_basis'],row['current_price']))
        value = qty * price
        principal += D(row['invested'])
        assets += value + D(row['proceeds'])
        realized += D(row['realized_pnl'])
        floating += value - basis
        distribution[row['category']] = distribution.get(row['category'],ZERO) + value
        pnl_by_category[row['category']] = pnl_by_category.get(row['category'],ZERO) + (value - basis + D(row['realized_pnl']))
    adjustment = sum((D(r[0]) for r in db.execute('SELECT amount FROM ledger_adjustments')),ZERO) if not category else ZERO
    assets += adjustment
    today = datetime.now(TZ).date().isoformat()
    previous = db.execute('SELECT pnl FROM ledger_snapshots WHERE category=? AND day<? ORDER BY day DESC LIMIT 1', (category or 'all',today)).fetchone()
    pnl = assets-principal
    # 今日盈亏只来自非平账项目的行情/交易变动。平账项目记录历史盈亏，
    # 其 pnl 贡献（= realized_pnl）一律从今日盈亏中扣除，避免冲垮当日数据。
    # 仅在总账视图（category=None）扣除；大类快照本身不含平账项目，无需再扣。
    skip_today = ZERO
    if not category:
        for r in db.execute("SELECT realized_pnl FROM projects WHERE category='settle' AND created_at LIKE ?", (today+'%',)):
            skip_today += D(r['realized_pnl'])
    daily = money(pnl-D(previous['pnl'])-skip_today) if previous else None
    return dict(principal=money(principal),assets=money(assets),pnl=money(pnl),
                today_pnl=daily,realized_pnl=money(realized),unrealized_pnl=money(floating),
                adjustments=money(adjustment),distribution=[dict(name=k,value=money(v)) for k,v in distribution.items()],
                pnl_distribution=[dict(name=k,value=money(v)) for k,v in pnl_by_category.items()],
                project_count=len(rows),active_count=sum(r['status']=='active' for r in rows))


def snapshot(db):
    stamp=now()
    for cat in [None]+[r['id'] for r in db.execute('SELECT id FROM categories')]:
        totals=ledger(db,cat)
        db.execute('''INSERT INTO ledger_snapshots(day,category,principal,assets,pnl,created_at) VALUES(?,?,?,?,?,?)
            ON CONFLICT(day,category) DO UPDATE SET principal=excluded.principal,assets=excluded.assets,
            pnl=excluded.pnl,created_at=excluded.created_at''',
            (stamp[:10],cat or 'all',totals['principal'],totals['assets'],totals['pnl'],stamp))


def daily_series(db, start, end, category='all'):
    # 差分基准取范围前最近一个快照日，跨范围连续累计。
    base = db.execute("SELECT pnl FROM ledger_snapshots WHERE category=? AND day<? ORDER BY day DESC LIMIT 1", (category,start)).fetchone()
    prev = D(base['pnl']) if base else None
    items = []
    for r in db.execute("SELECT day,pnl,assets FROM ledger_snapshots WHERE category=? AND day>=? AND day<=? ORDER BY day", (category, start, end)):
        pnl = D(r['pnl'])
        # 日度盈亏排除当天创建的平账项目，与今日盈亏口径一致。
        # 仅总账视图（category='all'）扣除；大类快照本身不含平账项目。
        settle = ZERO
        if category == 'all':
            settle = sum((D(x[0]) for x in db.execute("SELECT realized_pnl FROM projects WHERE category='settle' AND created_at LIKE ?", (r['day']+'%',))), ZERO)
        items.append(dict(day=r['day'], pnl=money(pnl),
                          daily=money(pnl-prev-settle) if prev is not None else None, assets=r['assets']))
        prev = pnl
    return items


def day_detail(db, day, category='all'):
    totals = db.execute("SELECT principal,assets,pnl FROM ledger_snapshots WHERE category=? AND day=?", (category,day)).fetchone()
    base = db.execute("SELECT pnl FROM ledger_snapshots WHERE category=? AND day<? ORDER BY day DESC LIMIT 1", (category,day)).fetchone()
    rows = db.execute('''SELECT o.id,o.kind,o.price,o.quantity,o.fee,o.realized_pnl,o.note,o.created_at,
        p.name AS project_name,p.code,p.instrument_name,p.category
        FROM operations o JOIN projects p ON p.id=o.project_id
        WHERE o.created_at LIKE ? ORDER BY o.created_at DESC,o.id DESC LIMIT 100''', (day+'%',)).fetchall()
    summary = None
    if totals:
        pnl, prev = D(totals['pnl']), (D(base['pnl']) if base else None)
        # 仅总账视图扣除当天平账；大类快照本身不含平账项目。
        settle = ZERO
        if category == 'all':
            settle = sum((D(x[0]) for x in db.execute("SELECT realized_pnl FROM projects WHERE category='settle' AND created_at LIKE ?", (day+'%',))), ZERO)
        summary = dict(day=day, principal=totals['principal'], assets=totals['assets'], pnl=totals['pnl'],
                       daily=money(pnl-prev-settle) if prev is not None else None)
    return dict(day=day, totals=summary, operations=[dict(r) for r in rows])
